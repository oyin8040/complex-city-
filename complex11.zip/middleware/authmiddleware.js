
"use strict";

function requireAuth(req, res, next) {
  return res.status(401).json({
    success: false,
    message: "Authentication is required to access this resource."
  });
}

module.exports = {
  requireAuth
};
