

"use strict";

import {
  auth,
  db,
  onAuthStateChanged,
  signOut,
  doc,
  getDoc,
  collection,
  getDocs
} from "./firebase.js";

const $ = (id) => document.getElementById(id);

function setText(id, value) {
  const element = $(id);
  if (element) element.textContent = value ?? "";
}

function showMessage(message, type = "error") {
  const element = $("dashboardMessage");
  if (!element) return;

  element.hidden = false;
  element.textContent = message;
  element.className = "dashboard-message " + type;
}

function money(value) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 2
  }).format(Number(value) || 0);
}

function getInitial(name, fallback) {
  return String(name || fallback || "?")
    .trim()
    .charAt(0)
    .toUpperCase();
}

function clearSession() {
  [
    "businessId",
    "businessName",
    "businessStatus",
    "accountType"
  ].forEach((key) => sessionStorage.removeItem(key));
}

async function loadDashboard(user) {
  const businessRef = doc(db, "businesses", user.uid);
  const businessSnapshot = await getDoc(businessRef);

  if (!businessSnapshot.exists()) {
    throw new Error(
      "Your business profile was not found. Please contact support."
    );
  }

  const business = businessSnapshot.data();

  if (
    business.ownerUid !== user.uid ||
    business.businessId !== user.uid
  ) {
    throw new Error("Your business ownership could not be verified.");
  }

  if (["suspended", "disabled"].includes(business.status)) {
    throw new Error(
      "This business account is restricted. Please contact support."
    );
  }

  const userSnapshot = await getDoc(doc(db, "users", user.uid));
  const owner = userSnapshot.exists() ? userSnapshot.data() : {};

  const ownerName =
    owner.fullName ||
    business.ownerName ||
    user.displayName ||
    "Business Owner";

  const businessName = business.businessName || "My Business";
  const category = business.category || "Business account";
  const status = business.status || "unknown";

  // Update dashboard identity.
  setText("businessName", businessName);
  setText("businessCategory", category);
  setText("ownerName", ownerName);
  setText("welcomeName", ownerName);
  setText("accountStatus", status.replaceAll("_", " "));
  setText("businessAvatar", getInitial(businessName, "B"));
  setText("ownerAvatar", getInitial(ownerName, "O"));
  setText("topbarAvatar", getInitial(ownerName, "O"));

  setText(
    "welcomeDescription",
    `Manage ${businessName} and monitor your daily business activities.`
  );

  // Store display context only. Firestore rules remain responsible
  // for enforcing access to business data.
  sessionStorage.setItem("businessId", business.businessId);
  sessionStorage.setItem("businessName", businessName);
  sessionStorage.setItem("businessStatus", status);
  sessionStorage.setItem("accountType", "owner");

  // Load business records.
  const [productsSnapshot, transactionsSnapshot] = await Promise.all([
    getDocs(collection(db, "businesses", user.uid, "products")),
    getDocs(collection(db, "businesses", user.uid, "transactions"))
  ]);

  const products = productsSnapshot.docs.map((item) => ({
    id: item.id,
    ...item.data()
  }));

  const transactions = transactionsSnapshot.docs.map((item) => ({
    id: item.id,
    ...item.data()
  }));

  setText("totalProducts", products.length);

  const today = new Date();
  const startOfDay = new Date(
    today.getFullYear(),
    today.getMonth(),
    today.getDate()
  );

  const todaysTransactions = transactions.filter((transaction) => {
    if (transaction.status !== "completed") return false;

    const createdAt = transaction.createdAt?.toDate
      ? transaction.createdAt.toDate()
      : transaction.createdAt
        ? new Date(transaction.createdAt)
        : null;

    return createdAt && createdAt >= startOfDay;
  });

  const todaySales = todaysTransactions.reduce(
    (sum, transaction) => sum + (Number(transaction.totalAmount) || 0),
    0
  );

  setText("todaySales", money(todaySales));

  // Estimate current inventory value using available cost fields.
  const stockValue = products.reduce((sum, product) => {
    const quantity = Number(product.quantity) || 0;
    const cost = Number(
      product.costPrice ?? product.purchasePrice ?? 0
    );

    return sum + quantity * cost;
  }, 0);

  setText("stockValue", money(stockValue));

  const lowStockProducts = products.filter((product) => {
    const quantity = Number(product.quantity) || 0;
    const threshold = Number(product.lowStockThreshold ?? 5);

    return quantity <= threshold;
  });

  setText("lowStockCount", lowStockProducts.length);

  // Recent transactions.
  const recentBody = $("recentTransactions");

  if (recentBody) {
    recentBody.replaceChildren();

    const recentTransactions = [...transactions]
      .filter((item) => item.status === "completed")
      .sort((a, b) => {
        const timeA = a.createdAt?.toDate
          ? a.createdAt.toDate().getTime()
          : 0;
        const timeB = b.createdAt?.toDate
          ? b.createdAt.toDate().getTime()
          : 0;

        return timeB - timeA;
      })
      .slice(0, 5);

    if (!recentTransactions.length) {
      const row = document.createElement("tr");
      const cell = document.createElement("td");

      cell.colSpan = 5;
      cell.className = "empty-state";
      cell.textContent = "No completed transactions have been recorded yet.";

      row.appendChild(cell);
      recentBody.appendChild(row);
    } else {
      recentTransactions.forEach((transaction) => {
        const row = document.createElement("tr");

        const createdAt = transaction.createdAt?.toDate
          ? transaction.createdAt.toDate()
          : null;

        const values = [
          transaction.transactionId || transaction.id,
          createdAt ? createdAt.toLocaleDateString("en-NG") : "—",
          transaction.paymentMethod || "Sale",
          money(transaction.totalAmount),
          transaction.status || "Unknown"
        ];

        values.forEach((value) => {
          const cell = document.createElement("td");
          cell.textContent = String(value);
          row.appendChild(cell);
        });

        recentBody.appendChild(row);
      });
    }
  }

  // Low-stock alerts.
  const alerts = $("stockAlerts");

  if (alerts) {
    alerts.replaceChildren();

    if (!lowStockProducts.length) {
      const message = document.createElement("div");
      message.className = "empty-state";
      message.textContent = "No products currently need restocking.";
      alerts.appendChild(message);
    } else {
      lowStockProducts.slice(0, 8).forEach((product) => {
        const item = document.createElement("div");
        item.className = "stock-alert-item";

        const name = document.createElement("strong");
        name.textContent = product.name || product.productName || "Unnamed product";

        const quantity = document.createElement("span");
        quantity.textContent =
          `Remaining stock: ${Number(product.quantity) || 0}`;

        item.append(name, quantity);
        alerts.appendChild(item);
      });
    }
  }

  if (status === "pending_setup") {
    showMessage(
      "Your business is registered. Complete your setup before normal operations.",
      "success"
    );
  } else if (status === "active") {
    showMessage("Your business dashboard is ready.", "success");
  } else {
    showMessage("Please check your business account status.", "error");
  }
}

// Authenticate the owner before loading business data.
onAuthStateChanged(auth, async (user) => {
  if (!user) {
    clearSession();
    window.location.replace("login.html");
    return;
  }

  try {
    await loadDashboard(user);
  } catch (error) {
    console.error("Dashboard loading failed:", error);

    showMessage(
      error.code === "permission-denied"
        ? "Access denied by Firestore. Check your security rules."
        : error.message || "Unable to load your business dashboard.",
      "error"
    );
  }
});

// Sign out.
$("logoutButton")?.addEventListener("click", async () => {
  const button = $("logoutButton");
  button.disabled = true;
  button.textContent = "Signing out...";

  try {
    await signOut(auth);
    clearSession();
    window.location.replace("login.html");
  } catch (error) {
    console.error("Sign-out failed:", error);
    showMessage("Unable to sign out. Please try again.", "error");

    button.disabled = false;
    button.textContent = "↪ Sign Out";
  }
});
