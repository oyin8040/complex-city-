/* ==========================================
   ALI-HIKIMAH SALES MANAGEMENT
   File: public/js/sales.js
========================================== */

import {
  auth,
  db,
  onAuthStateChanged,
  doc,
  getDoc,
  collection,
  getDocs,
  runTransaction,
  serverTimestamp
} from "./firebase.js";

const $ = (id) => document.getElementById(id);

const businessNameElement = $("businessName");
const todaySalesElement = $("todaySales");
const transactionCountElement = $("transactionCount");
const itemsSoldElement = $("itemsSold");

const salesSearchForm = $("salesSearchForm");
const productSearchInput = $("productSearch");
const productSearchResults = $("productSearchResults");

const saleCartBody = $("saleCartBody");
const saleTotalElement = $("saleTotal");

const customerNameInput = $("customerName");
const paymentMethodInput = $("paymentMethod");
const completeSaleButton = $("completeSaleButton");
const salesMessage = $("salesMessage");
const recentSalesBody = $("recentSalesBody");

let currentUser = null;
let businessId = null;
let availableProducts = [];
let cart = [];
let recentSales = [];
let saleInProgress = false;
let searchTimer = null;

/* ==========================================
   HELPERS
========================================== */

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function money(value) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 2
  }).format(Number(value) || 0);
}

function showMessage(message, type = "info") {
  if (!salesMessage) return;

  salesMessage.textContent = message;
  salesMessage.className = `message ${type}`;
  salesMessage.hidden = false;
}

function clearMessage() {
  if (!salesMessage) return;

  salesMessage.textContent = "";
  salesMessage.hidden = true;
}

function reportError(stage, error) {
  console.error(`[SALES DEBUG] ${stage}`, error);

  const detail = error?.code
    ? `${error.code}: ${error.message || "Request failed"}`
    : error?.message || "Unknown error";

  showMessage(`${stage}: ${detail}`, "error");
}

function timestampToDate(value) {
  if (!value) return null;

  if (typeof value.toDate === "function") {
    return value.toDate();
  }

  if (value instanceof Date) {
    return value;
  }

  if (typeof value.seconds === "number") {
    return new Date(value.seconds * 1000);
  }

  return null;
}

function formatDate(value) {
  const date = timestampToDate(value);

  return date
    ? date.toLocaleString("en-NG", {
        dateStyle: "medium",
        timeStyle: "short"
      })
    : "Date unavailable";
}

function setButtonBusy(busy) {
  if (!completeSaleButton) return;

  completeSaleButton.disabled = busy || cart.length === 0;
  completeSaleButton.textContent = busy
    ? "Processing sale..."
    : "Complete Sale";
}

/* ==========================================
   LOAD BUSINESS PROFILE
========================================== */

async function loadBusinessProfile(user) {
  const businessRef = doc(db, "businesses", user.uid);
  const snapshot = await getDoc(businessRef);

  if (!snapshot.exists()) {
    throw new Error("Business profile was not found.");
  }

  const data = snapshot.data();

  if (
    data.ownerUid !== user.uid ||
    data.businessId !== user.uid
  ) {
    throw new Error("Business ownership verification failed.");
  }

  businessId = user.uid;

  if (businessNameElement) {
    businessNameElement.textContent =
      data.businessName || "My Business";
  }
}

/* ==========================================
   LOAD PRODUCTS
========================================== */

async function loadProducts() {
  const productsRef = collection(
    db,
    "businesses",
    businessId,
    "products"
  );

  const snapshot = await getDocs(productsRef);

  availableProducts = snapshot.docs
    .map((productDoc) => ({
      id: productDoc.id,
      ...productDoc.data()
    }))
    .filter((product) =>
      product.ownerUid === currentUser.uid &&
      product.businessId === businessId
    );
}

/* ==========================================
   SEARCH PRODUCTS
========================================== */

function renderProductResults(products) {
  if (!productSearchResults) return;

  if (!products.length) {
    productSearchResults.innerHTML =
      "<p>No matching products found.</p>";
    return;
  }

  productSearchResults.innerHTML = products.map((product) => {
    const quantity = Number(product.quantity) || 0;
    const price = Number(product.sellingPrice) || 0;

    return `
      <div class="product-result">
        <div>
          <strong>${escapeHTML(product.productName)}</strong>
          <p>
            Code: ${escapeHTML(product.productCode || "N/A")}
            · Stock: ${quantity}
            · Price: ${money(price)}
          </p>
        </div>

        <button
          type="button"
          data-add-product="${escapeHTML(product.id)}"
          ${quantity > 0 ? "" : "disabled"}
        >
          ${quantity > 0 ? "Add to Sale" : "Out of Stock"}
        </button>
      </div>
    `;
  }).join("");
}

function searchProducts() {
  const query =
    productSearchInput?.value.trim().toLowerCase() || "";

  if (!query) {
    if (productSearchResults) {
      productSearchResults.innerHTML =
        "<p>Type a product name or code to search.</p>";
    }
    return;
  }

  const matches = availableProducts.filter((product) => {
    const name = String(product.productName || "").toLowerCase();
    const code = String(product.productCode || "").toLowerCase();

    return name.includes(query) || code.includes(query);
  }).slice(0, 20);

  renderProductResults(matches);
}

function addProductToCart(productId) {
  const product = availableProducts.find(
    (item) => item.id === productId
  );

  if (!product) {
    showMessage("Product not found. Reload the inventory.", "error");
    return;
  }

  const stock = Number(product.quantity);
  const price = Number(product.sellingPrice);

  if (!Number.isInteger(stock) || stock < 0) {
    showMessage("Invalid stock information.", "error");
    return;
  }

  if (!Number.isFinite(price) || price < 0) {
    showMessage("Invalid selling price.", "error");
    return;
  }

  const existing = cart.find((item) => item.productId === productId);
  const nextQuantity = existing ? existing.quantity + 1 : 1;

  if (nextQuantity > stock) {
    showMessage("Not enough stock for that quantity.", "error");
    return;
  }

  if (existing) {
    existing.quantity = nextQuantity;
  } else {
    cart.push({
      productId: product.id,
      productName: product.productName,
      productCode: product.productCode || "",
      sellingPrice: price,
      quantity: 1
    });
  }

  clearMessage();
  renderCart();
}

/* ==========================================
   CART
========================================== */

function renderCart() {
  if (!saleCartBody || !saleTotalElement) return;

  if (!cart.length) {
    saleCartBody.innerHTML =
      '<tr><td colspan="5">No products added yet.</td></tr>';
  } else {
    saleCartBody.innerHTML = cart.map((item) => `
      <tr>
        <td>${escapeHTML(item.productName)}</td>
        <td>${money(item.sellingPrice)}</td>
        <td>
          <button type="button"
            data-cart-action="decrease"
            data-product-id="${escapeHTML(item.productId)}">−</button>
          <strong>${item.quantity}</strong>
          <button type="button"
            data-cart-action="increase"
            data-product-id="${escapeHTML(item.productId)}">+</button>
        </td>
        <td>${money(item.sellingPrice * item.quantity)}</td>
        <td>
          <button type="button"
            data-cart-action="remove"
            data-product-id="${escapeHTML(item.productId)}">Remove</button>
        </td>
      </tr>
    `).join("");
  }

  const total = cart.reduce(
    (sum, item) => sum + item.sellingPrice * item.quantity,
    0
  );

  saleTotalElement.textContent = money(total);
  setButtonBusy(saleInProgress);
}

function changeCartQuantity(productId, action) {
  const item = cart.find((entry) => entry.productId === productId);
  if (!item) return;

  if (action === "remove") {
    cart = cart.filter((entry) => entry.productId !== productId);
  } else if (action === "decrease") {
    item.quantity -= 1;

    if (item.quantity <= 0) {
      cart = cart.filter((entry) => entry.productId !== productId);
    }
  } else if (action === "increase") {
    const product = availableProducts.find(
      (entry) => entry.id === productId
    );

    if (item.quantity >= Number(product?.quantity || 0)) {
      showMessage("You cannot exceed the available stock.", "error");
      return;
    }

    item.quantity += 1;
  }

  renderCart();
}

/* ==========================================
   LOAD RECENT SALES
========================================== */

async function loadRecentSales() {
  const salesRef = collection(
    db,
    "businesses",
    businessId,
    "transactions"
  );

  const snapshot = await getDocs(salesRef);

  recentSales = snapshot.docs
    .map((saleDoc) => ({
      id: saleDoc.id,
      ...saleDoc.data()
    }))
    .filter((sale) =>
      sale.ownerUid === currentUser.uid &&
      sale.businessId === businessId &&
      sale.status === "completed"
    )
    .sort((a, b) => {
      const dateA = timestampToDate(a.createdAt)?.getTime() || 0;
      const dateB = timestampToDate(b.createdAt)?.getTime() || 0;
      return dateB - dateA;
    });

  renderRecentSales();
  renderSalesSummary();
}

function renderRecentSales() {
  if (!recentSalesBody) return;

  if (!recentSales.length) {
    recentSalesBody.innerHTML =
      '<tr><td colspan="5">No completed sales recorded yet.</td></tr>';
    return;
  }

  recentSalesBody.innerHTML = recentSales.slice(0, 10).map((sale) => `
    <tr>
      <td>${escapeHTML(sale.transactionId || sale.id)}</td>
      <td>${escapeHTML(formatDate(sale.createdAt))}</td>
      <td>${Array.isArray(sale.items)
        ? sale.items.reduce(
            (sum, item) => sum + (Number(item.quantity) || 0), 0
          )
        : 0}</td>
      <td>${money(sale.totalAmount)}</td>
      <td>${escapeHTML(sale.paymentMethod || "N/A")}</td>
    </tr>
  `).join("");
}

function renderSalesSummary() {
  const now = new Date();
  const today = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate()
  );

  const todayRecords = recentSales.filter((sale) => {
    const date = timestampToDate(sale.createdAt);
    return date && date >= today;
  });

  const total = todayRecords.reduce(
    (sum, sale) => sum + (Number(sale.totalAmount) || 0),
    0
  );

  const itemsSold = todayRecords.reduce((sum, sale) => {
    const items = Array.isArray(sale.items) ? sale.items : [];
    return sum + items.reduce(
      (itemSum, item) => itemSum + (Number(item.quantity) || 0),
      0
    );
  }, 0);

  if (todaySalesElement) todaySalesElement.textContent = money(total);

  if (transactionCountElement) {
    transactionCountElement.textContent = String(todayRecords.length);
  }

  if (itemsSoldElement) {
    itemsSoldElement.textContent = String(itemsSold);
  }
}

/* ==========================================
   COMPLETE SALE ATOMICALLY
========================================== */

async function completeSale() {
  if (saleInProgress) return;

  if (!currentUser || !businessId) {
    showMessage("Please sign in again.", "error");
    return;
  }

  if (!cart.length) {
    showMessage("Add at least one product to the sale.", "error");
    return;
  }

  const paymentMethod = paymentMethodInput?.value || "";
  const allowedPayments = ["cash", "transfer", "pos", "other"];

  if (!allowedPayments.includes(paymentMethod)) {
    showMessage("Select a valid payment method.", "error");
    return;
  }

  const customerName =
    customerNameInput?.value.trim().slice(0, 120) ||
    "Walk-in customer";

  const cartSnapshot = cart.map((item) => ({ ...item }));

  saleInProgress = true;
  setButtonBusy(true);
  clearMessage();

  try {
    const transactionRef = doc(
      collection(db, "businesses", businessId, "transactions")
    );

    await runTransaction(db, async (transaction) => {
      const verifiedItems = [];

      // Read all products before writing any changes.
      for (const item of cartSnapshot) {
        if (
          !Number.isInteger(item.quantity) ||
          item.quantity < 1
        ) {
          throw new Error("Invalid quantity in the cart.");
        }

        const productRef = doc(
          db,
          "businesses",
          businessId,
          "products",
          item.productId
        );

        const productSnapshot = await transaction.get(productRef);

        if (!productSnapshot.exists()) {
          throw new Error(`${item.productName} no longer exists.`);
        }

        const product = productSnapshot.data();

        if (
          product.ownerUid !== currentUser.uid ||
          product.businessId !== businessId
        ) {
          throw new Error("Product ownership verification failed.");
        }

        const stock = product.quantity;
        const price = Number(product.sellingPrice);

        if (!Number.isInteger(stock) || stock < item.quantity) {
          throw new Error(`Insufficient stock for ${product.productName}.`);
        }

        if (!Number.isFinite(price) || price < 0) {
          throw new Error(`Invalid price for ${product.productName}.`);
        }

        verifiedItems.push({
          ref: productRef,
          id: item.productId,
          productName: product.productName,
          productCode: product.productCode || "",
          oldStock: stock,
          quantity: item.quantity,
          price
        });
      }

      const totalAmount = verifiedItems.reduce(
        (sum, item) => sum + item.quantity * item.price,
        0
      );

      const items = verifiedItems.map((item) => ({
        productId: item.id,
        productName: item.productName,
        productCode: item.productCode,
        quantity: item.quantity,
        sellingPrice: item.price,
        lineTotal: item.quantity * item.price
      }));

      // Update stock and create the sale in one commit.
      for (const item of verifiedItems) {
        transaction.update(item.ref, {
          quantity: item.oldStock - item.quantity,
          updatedAt: serverTimestamp()
        });
      }

      transaction.set(transactionRef, {
        ownerUid: currentUser.uid,
        businessId,
        transactionId: transactionRef.id,
        customerName,
        paymentMethod,
        items,
        totalAmount,
        status: "completed",
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    });

    cart = [];
    renderCart();

    if (customerNameInput) customerNameInput.value = "";
    if (paymentMethodInput) paymentMethodInput.value = "cash";

    showMessage(
      `Sale completed. Transaction ID: ${transactionRef.id}`,
      "success"
    );

    await loadProducts();
    await loadRecentSales();

    if (productSearchInput) productSearchInput.value = "";

    if (productSearchResults) {
      productSearchResults.innerHTML =
        "<p>Type a product name or code to search.</p>";
    }
  } catch (error) {
    reportError("Sale could not be completed", error);

    try {
      await loadProducts();
    } catch (refreshError) {
      console.error("Inventory refresh failed:", refreshError);
    }
  } finally {
    saleInProgress = false;
    setButtonBusy(false);
  }
}

/* ==========================================
   EVENT LISTENERS
========================================== */

if (salesSearchForm) {
  salesSearchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    searchProducts();
  });
}

if (productSearchInput) {
  productSearchInput.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(searchProducts, 200);
  });
}

if (productSearchResults) {
  productSearchResults.addEventListener("click", (event) => {
    const button = event.target.closest("[data-add-product]");

    if (button) {
      addProductToCart(button.dataset.addProduct);
    }
  });
}

if (saleCartBody) {
  saleCartBody.addEventListener("click", (event) => {
    const button = event.target.closest("[data-cart-action]");
    if (!button) return;

    changeCartQuantity(
      button.dataset.productId,
      button.dataset.cartAction
    );
  });
}

if (completeSaleButton) {
  completeSaleButton.addEventListener("click", completeSale);
}

/* ==========================================
   AUTHENTICATION AND INITIAL LOAD
========================================== */

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "login.html";
    return;
  }

  currentUser = user;

  try {
    showMessage("Loading your sales workspace...", "info");

    await loadBusinessProfile(user);
    await loadProducts();
    await loadRecentSales();

    renderCart();
    clearMessage();
  } catch (error) {
    reportError("Sales page initialization failed", error);
  }
});