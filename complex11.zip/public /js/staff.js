// ==========================================
// ALI-HIKIMAH BUSINESS PLATFORM
// STAFF MANAGEMENT
// SESSION 1 OF 5
// ==========================================

// FIREBASE IMPORTS
import { auth, db } from "./firebase.js";

import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";

import {
  doc,
  getDoc
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";


// ==========================================
// GLOBAL VARIABLES
// ==========================================

const STAFF_API_URL = "/api/staff";

let currentUser = null;
let businessId = null;
let businessData = null;

let allStaff = [];
let selectedStaff = null;

let savingStaff = false;
let processingStaffAction = false;


// ==========================================
// HTML ELEMENTS
// ==========================================

// BUSINESS
const businessNameElement =
  document.getElementById("businessName");


// STAFF SUMMARY
const totalStaffElement =
  document.getElementById("totalStaff");

const activeStaffElement =
  document.getElementById("activeStaff");

const disabledStaffElement =
  document.getElementById("disabledStaff");

const pendingStaffElement =
  document.getElementById("pendingStaff");


// STAFF REGISTRATION
const staffForm =
  document.getElementById("staffForm");

const staffNameInput =
  document.getElementById("staffName");

const staffRoleInput =
  document.getElementById("staffRole");

const staffPasswordInput =
  document.getElementById("staffPassword");

const confirmPasswordInput =
  document.getElementById("confirmStaffPassword");

const saveStaffButton =
  document.getElementById("saveStaffButton");

const staffMessage =
  document.getElementById("staffMessage");


// STAFF DIRECTORY
const staffSearchInput =
  document.getElementById("staffSearch");

const staffStatusFilter =
  document.getElementById("staffStatusFilter");

const staffTableBody =
  document.getElementById("staffTableBody");

const refreshStaffButton =
  document.getElementById("refreshStaffButton");


// STAFF MANAGEMENT PANEL
const staffActionPanel =
  document.getElementById("staffActionPanel");

const selectedStaffNameElement =
  document.getElementById("selectedStaffName");

const selectedStaffIdElement =
  document.getElementById("selectedStaffId");

const selectedStaffStatusElement =
  document.getElementById("selectedStaffStatus");


// PASSWORD RESET
const resetStaffPasswordForm =
  document.getElementById("resetStaffPasswordForm");

const resetStaffIdInput =
  document.getElementById("resetStaffId");

const newStaffPasswordInput =
  document.getElementById("newStaffPassword");

const confirmNewStaffPasswordInput =
  document.getElementById("confirmNewStaffPassword");

const resetStaffPasswordButton =
  document.getElementById("resetStaffPasswordButton");


// ACCOUNT CONTROL
const disableStaffButton =
  document.getElementById("disableStaffButton");

const activateStaffButton =
  document.getElementById("activateStaffButton");

const closeStaffActionButton =
  document.getElementById("closeStaffActionButton");

const staffActionMessage =
  document.getElementById("staffActionMessage");


// ==========================================
// GENERAL HELPER FUNCTIONS
// ==========================================

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => {
    const replacements = {
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    };

    return replacements[character];
  });
}


function showMessage(message, type = "error") {
  if (!staffMessage) return;

  staffMessage.textContent = message;
  staffMessage.style.color =
    type === "success" ? "green" : "red";
}


function clearMessage() {
  if (!staffMessage) return;

  staffMessage.textContent = "";
}


function showActionMessage(message, type = "error") {
  if (!staffActionMessage) return;

  staffActionMessage.textContent = message;
  staffActionMessage.style.color =
    type === "success" ? "green" : "red";
}


function clearActionMessage() {
  if (!staffActionMessage) return;

  staffActionMessage.textContent = "";
}


function clearBusinessSession() {
  currentUser = null;
  businessId = null;
  businessData = null;
  allStaff = [];
  selectedStaff = null;

  sessionStorage.removeItem("businessId");
}


// ==========================================
// GET OWNER AUTHENTICATION TOKEN
// ==========================================

async function getOwnerToken() {
  if (!currentUser) {
    throw new Error("Owner is not authenticated.");
  }

  return await currentUser.getIdToken();
}


// ==========================================
// VERIFY BUSINESS OWNER
// ==========================================

async function loadBusinessProfile(user) {

  if (!user) {
    throw new Error("Please log in again.");
  }

  const ownerId = user.uid;

  // LOAD BUSINESS DOCUMENT
  const businessRef = doc(
    db,
    "businesses",
    ownerId
  );

  const businessSnapshot = await getDoc(businessRef);

  if (!businessSnapshot.exists()) {
    throw new Error("Business profile was not found.");
  }

  const business = businessSnapshot.data();

  // VERIFY BUSINESS OWNERSHIP
  if (
    business.ownerUid !== ownerId ||
    business.businessId !== ownerId
  ) {
    throw new Error("You are not authorized to manage this business.");
  }

  // CHECK BUSINESS STATUS
  if (
    business.status === "suspended" ||
    business.status === "disabled"
  ) {
    throw new Error("This business account is currently disabled.");
  }

  // LOAD OWNER USER DOCUMENT
  const userRef = doc(
    db,
    "users",
    ownerId
  );

  const userSnapshot = await getDoc(userRef);

  if (!userSnapshot.exists()) {
    throw new Error("Owner account information was not found.");
  }

  const ownerData = userSnapshot.data();

  if (
    ownerData.role !== "owner" ||
    ownerData.businessId !== ownerId
  ) {
    throw new Error("Your owner account could not be verified.");
  }

  // SAVE VERIFIED INFORMATION
  currentUser = user;
  businessId = ownerId;
  businessData = business;

  sessionStorage.setItem("businessId", businessId);

  if (businessNameElement) {
    businessNameElement.textContent =
      business.businessName ||
      business.name ||
      "My Business";
  }

  return true;
}


// ==========================================
// END OF SESSION 1
// SESSION 2 CONTINUES BELOW THIS LINE
// ==========================================
// ==========================================
// SESSION 2 OF 5
// LOAD AND DISPLAY STAFF
// ==========================================


// ==========================================
// LOAD STAFF FROM BACKEND
// ==========================================

async function loadStaff() {

  if (!businessId || !currentUser) {
    showMessage("Business authentication is missing.");
    return false;
  }

  try {

    const token = await getOwnerToken();

    const response = await fetch(STAFF_API_URL, {
      method: "GET",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      }
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(
        result.message || "Unable to load staff."
      );
    }

    allStaff = Array.isArray(result.staff)
      ? result.staff.map(staff => ({
          ...staff,
          id: staff.id || staff.staffId
        }))
      : [];

    updateStaffSummary();
    displayStaff();

    return true;

  } catch (error) {

    console.error("Load staff error:", error);

    showMessage(
      error.message || "Failed to load staff."
    );

    return false;
  }
}


// ==========================================
// UPDATE STAFF SUMMARY
// ==========================================

function updateStaffSummary() {

  const total = allStaff.length;

  const active = allStaff.filter(
    staff => staff.status === "active"
  ).length;

  const disabled = allStaff.filter(
    staff => staff.status === "disabled"
  ).length;

  const pending = allStaff.filter(
    staff =>
      staff.status === "pending" ||
      staff.status === "provisioning"
  ).length;

  if (totalStaffElement) {
    totalStaffElement.textContent = total;
  }

  if (activeStaffElement) {
    activeStaffElement.textContent = active;
  }

  if (disabledStaffElement) {
    disabledStaffElement.textContent = disabled;
  }

  if (pendingStaffElement) {
    pendingStaffElement.textContent = pending;
  }
}


// ==========================================
// FORMAT STAFF STATUS
// ==========================================

function formatStaffStatus(status) {

  const statusLabels = {
    active: "Active",
    disabled: "Disabled",
    pending: "Pending",
    provisioning: "Provisioning"
  };

  return statusLabels[status] || "Unknown";
}


// ==========================================
// DISPLAY STAFF DIRECTORY
// ==========================================

function displayStaff() {

  if (!staffTableBody) return;

  const searchTerm = (
    staffSearchInput?.value || ""
  ).trim().toLowerCase();

  const selectedStatus =
    staffStatusFilter?.value || "all";

  const filteredStaff = allStaff.filter(staff => {

    const name = String(staff.name || "").toLowerCase();

    const staffId = String(
      staff.staffId || staff.id || ""
    ).toLowerCase();

    const role = String(
      staff.role || ""
    ).toLowerCase();

    const matchesSearch =
      name.includes(searchTerm) ||
      staffId.includes(searchTerm) ||
      role.includes(searchTerm);

    const matchesStatus =
      selectedStatus === "all" ||
      staff.status === selectedStatus;

    return matchesSearch && matchesStatus;
  });


  // SHOW EMPTY DIRECTORY MESSAGE

  if (filteredStaff.length === 0) {

    staffTableBody.innerHTML = `
      <tr>
        <td colspan="5">
          No staff members found.
        </td>
      </tr>
    `;

    return;
  }


  // DISPLAY STAFF ROWS

  staffTableBody.innerHTML = filteredStaff.map(staff => {

    const staffId = staff.id || staff.staffId;

    return `
      <tr data-staff-id="${escapeHTML(staffId)}">

        <td>
          ${escapeHTML(staff.name || "Unnamed")}
        </td>

        <td>
          ${escapeHTML(staffId || "N/A")}
        </td>

        <td>
          ${escapeHTML(staff.role || "Staff")}
        </td>

        <td>
          ${escapeHTML(formatStaffStatus(staff.status))}
        </td>

        <td>
          <button
            type="button"
            class="manage-staff-button"
            data-staff-id="${escapeHTML(staffId)}"
          >
            Manage
          </button>
        </td>

      </tr>
    `;

  }).join("");
}


// ==========================================
// END OF SESSION 2
// SESSION 3 CONTINUES BELOW THIS LINE
// ==========================================
// ==========================================
// SESSION 3 OF 5
// REGISTER AND SELECT STAFF
// ==========================================


// ==========================================
// REGISTER NEW STAFF
// ==========================================

async function registerStaff(event) {

  event.preventDefault();

  if (savingStaff) return;

  clearMessage();

  const name = staffNameInput?.value.trim();
  const role = staffRoleInput?.value;
  const password = staffPasswordInput?.value;
  const confirmPassword = confirmPasswordInput?.value;

  if (!name || !role || !password || !confirmPassword) {
    showMessage("Please complete all staff registration fields.");
    return;
  }

  if (password.length < 8 || password.length > 64) {
    showMessage("Password must contain between 8 and 64 characters.");
    return;
  }

  if (password !== confirmPassword) {
    showMessage("Passwords do not match.");
    return;
  }

  if (!businessId || !currentUser) {
    showMessage("Business authentication is missing.");
    return;
  }

  try {

    savingStaff = true;

    if (saveStaffButton) {
      saveStaffButton.disabled = true;
      saveStaffButton.textContent = "Registering...";
    }

    const token = await getOwnerToken();

    const response = await fetch(STAFF_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        name,
        role,
        password,
        businessId
      })
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(
        result.message || "Staff registration failed."
      );
    }

    if (staffForm) {
      staffForm.reset();
    }

    const refreshSuccessful = await loadStaff();

    if (refreshSuccessful) {
      showMessage(
        `Staff registered successfully. Staff ID: ${result.staff?.staffId || "Created"}`,
        "success"
      );
    } else {
      showMessage(
        "Staff was registered, but the directory could not refresh. Please refresh the list.",
        "error"
      );
    }

  } catch (error) {

    console.error("Register staff error:", error);

    showMessage(
      error.message || "Unable to register staff."
    );

  } finally {

    savingStaff = false;

    if (saveStaffButton) {
      saveStaffButton.disabled = false;
      saveStaffButton.textContent = "Register Staff";
    }
  }
}


// ==========================================
// SELECT STAFF FOR MANAGEMENT
// ==========================================

function selectStaff(staffDocumentId) {

  const staff = allStaff.find(item =>
    String(item.id || item.staffId) ===
    String(staffDocumentId)
  );

  if (!staff) {
    showActionMessage("Staff member was not found.");
    return;
  }

  selectedStaff = staff;

  if (staffActionPanel) {
    staffActionPanel.style.display = "block";
  }

  if (selectedStaffNameElement) {
    selectedStaffNameElement.textContent =
      staff.name || "Unnamed";
  }

  if (selectedStaffIdElement) {
    selectedStaffIdElement.textContent =
      staff.staffId || staff.id || "N/A";
  }

  if (selectedStaffStatusElement) {
    selectedStaffStatusElement.textContent =
      formatStaffStatus(staff.status);
  }

  if (resetStaffIdInput) {
    resetStaffIdInput.value =
      staff.staffId || staff.id || "";
  }

  if (disableStaffButton) {
    disableStaffButton.style.display =
      staff.status === "active" ? "inline-block" : "none";
  }

  if (activateStaffButton) {
    activateStaffButton.style.display =
      staff.status === "disabled" ? "inline-block" : "none";
  }

  clearActionMessage();
}


// ==========================================
// CLOSE STAFF MANAGEMENT PANEL
// ==========================================

function closeStaffManagement() {

  selectedStaff = null;

  if (staffActionPanel) {
    staffActionPanel.style.display = "none";
  }

  if (resetStaffPasswordForm) {
    resetStaffPasswordForm.reset();
  }

  clearActionMessage();
}


// ==========================================
// END OF SESSION 3
// SESSION 4 CONTINUES BELOW THIS LINE
// ==========================================
// ==========================================
// SESSION 4 OF 5
// PASSWORD RESET AND ACCOUNT CONTROL
// ==========================================


// ==========================================
// RESET STAFF PASSWORD
// ==========================================

async function resetStaffPassword(event) {

  event.preventDefault();

  if (processingStaffAction) return;

  clearActionMessage();

  const staffId = resetStaffIdInput?.value.trim();
  const newPassword = newStaffPasswordInput?.value;
  const confirmPassword =
    confirmNewStaffPasswordInput?.value;

  if (!staffId || !newPassword || !confirmPassword) {
    showActionMessage("Please complete all password fields.");
    return;
  }

  if (newPassword.length < 8 || newPassword.length > 64) {
    showActionMessage(
      "Password must contain between 8 and 64 characters."
    );
    return;
  }

  if (newPassword !== confirmPassword) {
    showActionMessage("Passwords do not match.");
    return;
  }

  try {

    processingStaffAction = true;

    if (resetStaffPasswordButton) {
      resetStaffPasswordButton.disabled = true;
      resetStaffPasswordButton.textContent = "Updating...";
    }

    const token = await getOwnerToken();

    const response = await fetch(
      `${STAFF_API_URL}/${encodeURIComponent(staffId)}/password`,
      {
        method: "PATCH",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          password: newPassword
        })
      }
    );

    const result = await response.json();

    if (!response.ok) {
      throw new Error(
        result.message || "Password reset failed."
      );
    }

    if (resetStaffPasswordForm) {
      resetStaffPasswordForm.reset();
    }

    showActionMessage(
      "Staff password updated successfully.",
      "success"
    );

  } catch (error) {

    console.error("Password reset error:", error);

    showActionMessage(
      error.message || "Unable to reset staff password."
    );

  } finally {

    processingStaffAction = false;

    if (resetStaffPasswordButton) {
      resetStaffPasswordButton.disabled = false;
      resetStaffPasswordButton.textContent = "Reset Password";
    }
  }
}


// ==========================================
// ACTIVATE OR DISABLE STAFF ACCOUNT
// ==========================================

async function updateStaffStatus(newStatus) {

  if (processingStaffAction) return;

  if (!selectedStaff) {
    showActionMessage("Please select a staff member first.");
    return;
  }

  if (!["active", "disabled"].includes(newStatus)) {
    showActionMessage("Invalid account status.");
    return;
  }

  const staffId =
    selectedStaff.staffId || selectedStaff.id;

  if (!staffId) {
    showActionMessage("Staff ID is missing.");
    return;
  }

  try {

    processingStaffAction = true;

    if (disableStaffButton) {
      disableStaffButton.disabled = true;
    }

    if (activateStaffButton) {
      activateStaffButton.disabled = true;
    }

    showActionMessage("Updating staff account...");

    const token = await getOwnerToken();

    const response = await fetch(
      `${STAFF_API_URL}/${encodeURIComponent(staffId)}/status`,
      {
        method: "PATCH",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          status: newStatus
        })
      }
    );

    const result = await response.json();

    if (!response.ok) {
      throw new Error(
        result.message || "Unable to update staff status."
      );
    }

    const refreshSuccessful = await loadStaff();

    if (!refreshSuccessful) {
      showActionMessage(
        "Account status was updated, but the directory could not refresh."
      );
      return;
    }

    // SELECT THE UPDATED STAFF MEMBER AGAIN

    const updatedStaff = allStaff.find(item =>
      String(item.staffId || item.id) === String(staffId)
    );

    if (updatedStaff) {
      selectStaff(updatedStaff.id || updatedStaff.staffId);
    }

    showActionMessage(
      newStatus === "active"
        ? "Staff account activated successfully."
        : "Staff account disabled successfully.",
      "success"
    );

  } catch (error) {

    console.error("Staff status error:", error);

    showActionMessage(
      error.message || "Unable to update staff account."
    );

  } finally {

    processingStaffAction = false;

    if (disableStaffButton) {
      disableStaffButton.disabled = false;
    }

    if (activateStaffButton) {
      activateStaffButton.disabled = false;
    }
  }
}


// ==========================================
// END OF SESSION 4
// SESSION 5 CONTINUES BELOW THIS LINE
// ==========================================
// ==========================================
// SESSION 5 OF 5
// EVENT LISTENERS AND PAGE INITIALIZATION
// ==========================================


// ==========================================
// SET UP STAFF PAGE EVENTS
// ==========================================

function setupStaffEventListeners() {

  // STAFF REGISTRATION

  if (staffForm) {
    staffForm.addEventListener(
      "submit",
      registerStaff
    );
  }


  // SEARCH STAFF

  if (staffSearchInput) {
    staffSearchInput.addEventListener(
      "input",
      displayStaff
    );
  }


  // FILTER STAFF

  if (staffStatusFilter) {
    staffStatusFilter.addEventListener(
      "change",
      displayStaff
    );
  }


  // REFRESH STAFF DIRECTORY

  if (refreshStaffButton) {
    refreshStaffButton.addEventListener(
      "click",
      async () => {
        clearMessage();

        refreshStaffButton.disabled = true;

        await loadStaff();

        refreshStaffButton.disabled = false;
      }
    );
  }


  // MANAGE STAFF BUTTON

  if (staffTableBody) {
    staffTableBody.addEventListener(
      "click",
      event => {

        const button = event.target.closest(
          ".manage-staff-button"
        );

        if (!button) return;

        const staffId = button.dataset.staffId;

        selectStaff(staffId);
      }
    );
  }


  // RESET STAFF PASSWORD

  if (resetStaffPasswordForm) {
    resetStaffPasswordForm.addEventListener(
      "submit",
      resetStaffPassword
    );
  }


  // DISABLE STAFF ACCOUNT

  if (disableStaffButton) {
    disableStaffButton.addEventListener(
      "click",
      () => {
        updateStaffStatus("disabled");
      }
    );
  }


  // ACTIVATE STAFF ACCOUNT

  if (activateStaffButton) {
    activateStaffButton.addEventListener(
      "click",
      () => {
        updateStaffStatus("active");
      }
    );
  }


  // CLOSE MANAGEMENT PANEL

  if (closeStaffActionButton) {
    closeStaffActionButton.addEventListener(
      "click",
      closeStaffManagement
    );
  }
}


// ==========================================
// INITIALIZE STAFF PAGE
// ==========================================

async function initializeStaffPage(user) {

  try {

    currentUser = user;

    // VERIFY BUSINESS OWNER

    await loadBusinessProfile(user);

    // CONNECT PAGE EVENTS

    setupStaffEventListeners();

    // LOAD STAFF DIRECTORY

    const loaded = await loadStaff();

    if (loaded) {
      console.log(
        "Ali-Hikimah Staff Management loaded successfully."
      );
    }

  } catch (error) {

    console.error(
      "Staff page initialization error:",
      error
    );

    clearBusinessSession();

    showMessage(
      error.message || "Unable to load staff management."
    );
  }
}


// ==========================================
// FIREBASE AUTHENTICATION LISTENER
// ==========================================

onAuthStateChanged(auth, async user => {

  if (!user) {

    clearBusinessSession();

    window.location.href = "login.html";

    return;
  }

  await initializeStaffPage(user);
});


// ==========================================
// END OF STAFF.JS
// ALL 5 SESSIONS COMPLETED
// ==========================================