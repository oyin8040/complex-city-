
/* ==========================================
   ALI-HIKIMAH COMPLEX BUSINESS PLATFORM
   File: public/js/login.js
   Purpose: Owner and staff authentication
========================================== */

import {
  auth,
  db,
  signInWithEmailAndPassword,
  signInWithCustomToken,
  signOut,
  doc,
  getDoc
} from "./firebase.js";

"use strict";

document.addEventListener("DOMContentLoaded", () => {

  const loginForm = document.getElementById("loginForm");
  const loginIdentifier = document.getElementById("loginIdentifier");
  const passwordInput = document.getElementById("password");
  const loginButton = document.getElementById("loginButton");
  const loginMessage = document.getElementById("loginMessage");

  if (
    !loginForm ||
    !loginIdentifier ||
    !passwordInput ||
    !loginButton ||
    !loginMessage
  ) {
    console.error("Login form elements are missing.");
    return;
  }

  function showMessage(message, type = "error") {
    loginMessage.textContent = message;
    loginMessage.hidden = false;
    loginMessage.className = `form-message ${type}`;
  }

  function setLoading(isLoading) {
    loginButton.disabled = isLoading;
    loginButton.textContent = isLoading
      ? "Signing in..."
      : "Sign In";
  }

  function getErrorMessage(error) {
    console.error("Login error:", error);

    const messages = {
      "auth/invalid-credential":
        "Incorrect email or password.",
      "auth/user-not-found":
        "No account was found with these details.",
      "auth/wrong-password":
        "Incorrect password.",
      "auth/too-many-requests":
        "Too many attempts. Please try again later.",
      "auth/network-request-failed":
        "Network connection failed. Check your internet.",
      "auth/invalid-email":
        "Enter a valid email address.",
      "permission-denied":
        "Access denied. Check your account permissions."
    };

    return messages[error.code] ||
      error.message ||
      "Login failed. Please try again.";
  }

  // ========================================
  // OWNER LOGIN
  // ========================================

  async function ownerLogin(email, password) {

    const credential = await signInWithEmailAndPassword(
      auth,
      email,
      password
    );

    const user = credential.user;

    const businessRef = doc(db, "businesses", user.uid);
    const businessSnapshot = await getDoc(businessRef);

    if (!businessSnapshot.exists()) {
      await signOut(auth);

      throw new Error(
        "Your business profile was not found. Please complete registration or contact support."
      );
    }

    const business = businessSnapshot.data();

    if (business.ownerUid !== user.uid) {
      await signOut(auth);

      throw new Error(
        "This business account is not authorized for your login."
      );
    }

    // Allow newly registered businesses to complete setup.
    const allowedStatuses = [
      "active",
      "pending_setup"
    ];

    if (!allowedStatuses.includes(business.status)) {
      await signOut(auth);

      throw new Error(
        "Your business account is suspended, disabled or not yet authorized."
      );
    }

    sessionStorage.setItem("userRole", "owner");
    sessionStorage.setItem("businessId", user.uid);
    sessionStorage.setItem("ownerUid", user.uid);
    sessionStorage.setItem("businessStatus", business.status);

    window.location.href = "dashboard.html";
  }

  // ========================================
  // STAFF LOGIN
  // ========================================

  async function staffLogin(staffId, password) {

    const response = await fetch("/api/staff/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        staffId,
        password
      })
    });

    let result;

    try {
      result = await response.json();
    } catch {
      throw new Error(
        "The server returned an invalid response."
      );
    }

    if (!response.ok || !result.success) {
      throw new Error(
        result.message || "Staff login failed."
      );
    }

    if (!result.customToken || !result.staff) {
      throw new Error(
        "Staff authentication information is incomplete."
      );
    }

    const credential = await signInWithCustomToken(
      auth,
      result.customToken
    );

    const user = credential.user;

    const tokenResult = await user.getIdTokenResult();
    const claims = tokenResult.claims;

    if (
      claims.role !== "staff" ||
      claims.staffId !== staffId ||
      claims.businessId !== result.staff.businessId
    ) {
      await signOut(auth);

      throw new Error(
        "Your staff account could not be verified."
      );
    }

    if (result.staff.uid !== user.uid) {
      await signOut(auth);

      throw new Error(
        "Staff account verification failed."
      );
    }

    sessionStorage.setItem("userRole", "staff");
    sessionStorage.setItem("staffId", staffId);
    sessionStorage.setItem("businessId", result.staff.businessId);
    sessionStorage.setItem("staffUid", user.uid);
    sessionStorage.setItem("staffName", result.staff.name || "");

    window.location.href = "sales-dashboard.html";
  }

  // ========================================
  // MAIN LOGIN FORM
  // ========================================

  loginForm.addEventListener("submit", async (event) => {

    event.preventDefault();

    const identifier = loginIdentifier.value.trim();
    const password = passwordInput.value;

    if (!identifier || !password) {
      showMessage("Enter your login details.");
      return;
    }

    setLoading(true);

    try {

      sessionStorage.clear();

      await signOut(auth).catch(() => {});

      // Staff login identification.
      if (/^STAFF[0-9]{6}$/i.test(identifier)) {

        await staffLogin(
          identifier.toUpperCase(),
          password
        );

      } else {

        // Owner login identification.
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(identifier)) {
          throw new Error(
            "Enter a valid business email or Staff ID."
          );
        }

        await ownerLogin(
          identifier.toLowerCase(),
          password
        );
      }

    } catch (error) {

      showMessage(getErrorMessage(error));

    } finally {

      setLoading(false);

    }

  });

});
