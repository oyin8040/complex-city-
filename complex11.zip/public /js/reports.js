/* ==========================================
   ALI-HIKIMAH BUSINESS REPORTS
   File: public/js/reports.js
========================================== */

import {
  auth,
  db,
  onAuthStateChanged,
  doc,
  getDoc,
  collection,
  getDocs
} from "./firebase.js";

const $ = (id) => document.getElementById(id);

const businessNameElement = $("businessName");

const reportTotalSalesElement = $("reportTotalSales");
const reportTotalExpensesElement = $("reportTotalExpenses");
const reportEstimatedProfitElement = $("reportEstimatedProfit");
const reportProductCountElement = $("reportProductCount");

const reportFilterForm = $("reportFilterForm");
const reportStartDateInput = $("reportStartDate");
const reportEndDateInput = $("reportEndDate");
const reportTypeInput = $("reportType");

const generateReportButton = $("generateReportButton");
const printReportButton = $("printReportButton");
const reportsMessage = $("reportsMessage");

const reportOutput = $("reportOutput");
const reportHeading = $("reportHeading");
const reportPeriod = $("reportPeriod");
const reportTableHead = $("reportTableHead");
const reportTableBody = $("reportTableBody");

let currentUser = null;
let businessId = null;

let allTransactions = [];
let allExpenses = [];
let allProducts = [];

/* ==========================================
   HELPERS
========================================== */

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function money(value) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 2
  }).format(Number(value) || 0);
}

function showMessage(message, type = "info") {
  if (!reportsMessage) return;

  reportsMessage.textContent = message;
  reportsMessage.className = `message ${type}`;
  reportsMessage.hidden = false;
}

function clearMessage() {
  if (!reportsMessage) return;

  reportsMessage.textContent = "";
  reportsMessage.hidden = true;
}

function toDate(value) {
  if (!value) return null;

  if (typeof value.toDate === "function") {
    return value.toDate();
  }

  if (value instanceof Date) {
    return value;
  }

  if (typeof value.seconds === "number") {
    return new Date(value.seconds * 1000);
  }

  if (typeof value === "string") {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  return null;
}

function formatDate(value) {
  const date = toDate(value);

  if (!date) return "Date unavailable";

  return date.toLocaleDateString("en-NG", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

function dateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function getSelectedPeriod() {
  const startValue = reportStartDateInput?.value || "";
  const endValue = reportEndDateInput?.value || "";

  const start = startValue
    ? new Date(`${startValue}T00:00:00`)
    : null;

  const end = endValue
    ? new Date(`${endValue}T23:59:59.999`)
    : null;

  if (start && Number.isNaN(start.getTime())) {
    throw new Error("The report start date is invalid.");
  }

  if (end && Number.isNaN(end.getTime())) {
    throw new Error("The report end date is invalid.");
  }

  if (start && end && start > end) {
    throw new Error("Start date cannot be after end date.");
  }

  return { start, end, startValue, endValue };
}

function isWithinPeriod(value, start, end) {
  const date = toDate(value);

  if (!date) return false;
  if (start && date < start) return false;
  if (end && date > end) return false;

  return true;
}

function getTransactionItems(transaction) {
  return Array.isArray(transaction.items)
    ? transaction.items
    : [];
}

/* ==========================================
   LOAD BUSINESS PROFILE
========================================== */

async function loadBusinessProfile(user) {
  const businessRef = doc(db, "businesses", user.uid);
  const snapshot = await getDoc(businessRef);

  if (!snapshot.exists()) {
    throw new Error("Business profile was not found.");
  }

  const business = snapshot.data();

  if (
    business.ownerUid !== user.uid ||
    business.businessId !== user.uid
  ) {
    throw new Error("Business ownership verification failed.");
  }

  businessId = user.uid;

  if (businessNameElement) {
    businessNameElement.textContent =
      business.businessName || "My Business";
  }
}

/* ==========================================
   LOAD BUSINESS DATA
========================================== */

async function loadTransactions() {
  const ref = collection(
    db,
    "businesses",
    businessId,
    "transactions"
  );

  const snapshot = await getDocs(ref);

  allTransactions = snapshot.docs
    .map((item) => ({
      id: item.id,
      ...item.data()
    }))
    .filter((item) =>
      item.ownerUid === currentUser.uid &&
      item.businessId === businessId &&
      item.status === "completed"
    );
}

async function loadExpenses() {
  const ref = collection(
    db,
    "businesses",
    businessId,
    "expenses"
  );

  const snapshot = await getDocs(ref);

  allExpenses = snapshot.docs
    .map((item) => ({
      id: item.id,
      ...item.data()
    }))
    .filter((item) =>
      item.ownerUid === currentUser.uid &&
      item.businessId === businessId
    );
}

async function loadProducts() {
  const ref = collection(
    db,
    "businesses",
    businessId,
    "products"
  );

  const snapshot = await getDocs(ref);

  allProducts = snapshot.docs
    .map((item) => ({
      id: item.id,
      ...item.data()
    }))
    .filter((item) =>
      item.ownerUid === currentUser.uid &&
      item.businessId === businessId
    );
}

async function loadAllData() {
  await Promise.all([
    loadTransactions(),
    loadExpenses(),
    loadProducts()
  ]);

  renderOverview();
}

/* ==========================================
   SUMMARY CALCULATIONS
========================================== */

function renderOverview() {
  const totalSales = allTransactions.reduce(
    (sum, item) => sum + (Number(item.totalAmount) || 0),
    0
  );

  const totalExpenses = allExpenses.reduce(
    (sum, item) => sum + (Number(item.amount) || 0),
    0
  );

  const estimatedProfit = totalSales - totalExpenses;

  if (reportTotalSalesElement) {
    reportTotalSalesElement.textContent = money(totalSales);
  }

  if (reportTotalExpensesElement) {
    reportTotalExpensesElement.textContent = money(totalExpenses);
  }

  if (reportEstimatedProfitElement) {
    reportEstimatedProfitElement.textContent = money(estimatedProfit);
  }

  if (reportProductCountElement) {
    reportProductCountElement.textContent = String(allProducts.length);
  }
}

/* ==========================================
   REPORT FILTERING
========================================== */

function getFilteredData() {
  const { start, end, startValue, endValue } = getSelectedPeriod();

  const transactions = allTransactions.filter((item) =>
    isWithinPeriod(item.createdAt, start, end)
  );

  const expenses = allExpenses.filter((item) =>
    isWithinPeriod(item.expenseDate, start, end)
  );

  return {
    transactions,
    expenses,
    start,
    end,
    startValue,
    endValue
  };
}

/* ==========================================
   REPORT TABLE HELPERS
========================================== */

function setReportTable(headers, rows) {
  if (reportTableHead) {
    reportTableHead.innerHTML = `
      <tr>
        ${headers.map((header) =>
          `<th>${escapeHTML(header)}</th>`
        ).join("")}
      </tr>
    `;
  }

  if (!reportTableBody) return;

  if (!rows.length) {
    reportTableBody.innerHTML = `
      <tr>
        <td colspan="${Math.max(headers.length, 1)}">
          No records found for this report period.
        </td>
      </tr>
    `;
    return;
  }

  reportTableBody.innerHTML = rows.map((row) => `
    <tr>
      ${row.map((cell) =>
        `<td>${escapeHTML(cell)}</td>`
      ).join("")}
    </tr>
  `).join("");
}

function reportPeriodText(startValue, endValue) {
  if (startValue && endValue) {
    return `${startValue} to ${endValue}`;
  }

  if (startValue) return `From ${startValue}`;
  if (endValue) return `Until ${endValue}`;

  return "All available records";
}

/* ==========================================
   GENERATE REPORT
========================================== */

function generateReport(event) {
  if (event) event.preventDefault();

  try {
    clearMessage();

    const {
      transactions,
      expenses,
      startValue,
      endValue
    } = getFilteredData();

    const reportType = reportTypeInput?.value || "overview";

    const totalSales = transactions.reduce(
      (sum, item) => sum + (Number(item.totalAmount) || 0),
      0
    );

    const totalExpenses = expenses.reduce(
      (sum, item) => sum + (Number(item.amount) || 0),
      0
    );

    if (reportHeading) {
      const headings = {
        overview: "Business Overview Report",
        sales: "Sales Report",
        expenses: "Expenses Report",
        inventory: "Inventory Report",
        profit: "Profit Summary Report"
      };

      reportHeading.textContent =
        headings[reportType] || headings.overview;
    }

    if (reportPeriod) {
      reportPeriod.textContent =
        reportPeriodText(startValue, endValue);
    }

    if (reportOutput) {
      reportOutput.hidden = false;
    }

    if (reportType === "sales") {
      const rows = transactions.map((item) => [
        item.transactionId || item.id,
        formatDate(item.createdAt),
        item.customerName || "Walk-in customer",
        item.paymentMethod || "N/A",
        money(item.totalAmount)
      ]);

      setReportTable(
        ["Transaction ID", "Date", "Customer", "Payment", "Total"],
        rows
      );
    } else if (reportType === "expenses") {
      const rows = expenses.map((item) => [
        formatDate(item.expenseDate),
        item.title || "Expense",
        item.category || "Other",
        item.paymentMethod || "N/A",
        money(item.amount)
      ]);

      setReportTable(
        ["Date", "Description", "Category", "Payment", "Amount"],
        rows
      );
    } else if (reportType === "inventory") {
      const rows = allProducts.map((item) => [
        item.productName || "Unnamed product",
        item.productCode || "N/A",
        item.category || "Other",
        String(Number(item.quantity) || 0),
        money(item.costPrice),
        money(item.sellingPrice),
        money(
          (Number(item.quantity) || 0) *
          (Number(item.costPrice) || 0)
        )
      ]);

      setReportTable(
        [
          "Product",
          "Code",
          "Category",
          "Stock",
          "Cost Price",
          "Selling Price",
          "Stock Cost Value"
        ],
        rows
      );
    } else if (reportType === "profit") {
      const estimatedProfit = totalSales - totalExpenses;

      setReportTable(
        ["Metric", "Amount"],
        [
          ["Completed sales", money(totalSales)],
          ["Recorded expenses", money(totalExpenses)],
          ["Estimated profit before cost of goods", money(estimatedProfit)]
        ]
      );
    } else {
      setReportTable(
        ["Metric", "Value"],
        [
          ["Completed transactions", String(transactions.length)],
          ["Sales total", money(totalSales)],
          ["Recorded expenses", money(totalExpenses)],
          ["Estimated profit before cost of goods", money(totalSales - totalExpenses)],
          ["Products in inventory", String(allProducts.length)]
        ]
      );
    }

    showMessage("Report generated successfully.", "success");
  } catch (error) {
    console.error("[REPORTS DEBUG]", error);

    showMessage(
      `Could not generate report: ${
        error?.message || "Unknown error"
      }`,
      "error"
    );
  }
}

/* ==========================================
   PRINT REPORT
========================================== */

function printReport() {
  if (!reportOutput || reportOutput.hidden) {
    showMessage("Generate a report before printing.", "error");
    return;
  }

  window.print();
}

/* ==========================================
   EVENT LISTENERS
========================================== */

if (reportFilterForm) {
  reportFilterForm.addEventListener("submit", generateReport);
}

if (printReportButton) {
  printReportButton.addEventListener("click", printReport);
}

/* ==========================================
   AUTHENTICATION AND INITIALIZATION
========================================== */

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "login.html";
    return;
  }

  currentUser = user;

  try {
    showMessage("Loading business reports...", "info");

    await loadBusinessProfile(user);
    await loadAllData();

    // Default report dates to the current month.
    const now = new Date();
    const monthStart = new Date(
      now.getFullYear(),
      now.getMonth(),
      1
    );

    if (reportStartDateInput && !reportStartDateInput.value) {
      reportStartDateInput.value = dateKey(monthStart);
    }

    if (reportEndDateInput && !reportEndDateInput.value) {
      reportEndDateInput.value = dateKey(now);
    }

    generateReport();
    clearMessage();
  } catch (error) {
    console.error("[REPORTS DEBUG] Initialization failed", error);

    showMessage(
      `Could not load reports: ${
        error?.code || error?.message || "Unknown error"
      }`,
      "error"
    );
  }
});