
"use strict";

/* ==========================================
   ALI-HIKIMAH DIGITAL
   HOMEPAGE JAVASCRIPT
========================================== */

document.addEventListener("DOMContentLoaded", function () {

  // 1. MOBILE NAVIGATION
  const menuToggle = document.getElementById("menuToggle");
  const navigation = document.getElementById("navigation");

  if (menuToggle && navigation) {
    menuToggle.addEventListener("click", function () {
      const isOpen = navigation.classList.toggle("open");

      menuToggle.setAttribute(
        "aria-expanded",
        String(isOpen)
      );

      menuToggle.textContent = isOpen ? "✕" : "☰";
    });

    // Close menu after selecting a page
    navigation.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        navigation.classList.remove("open");

        menuToggle.setAttribute(
          "aria-expanded",
          "false"
        );

        menuToggle.textContent = "☰";
      });
    });

    // Close menu if the screen becomes desktop-sized
    window.addEventListener("resize", function () {
      if (window.innerWidth > 700) {
        navigation.classList.remove("open");

        menuToggle.setAttribute(
          "aria-expanded",
          "false"
        );

        menuToggle.textContent = "☰";
      }
    });
  }

  // 2. AUTOMATIC FOOTER YEAR
  const yearElement = document.getElementById("year");

  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  // 3. HIGHLIGHT THE CURRENT NAVIGATION PAGE
  const currentPage = window.location.pathname
    .split("/")
    .pop() || "index.html";

  document.querySelectorAll("#navigation a").forEach(function (link) {
    const destination = link.getAttribute("href");

    if (destination === currentPage) {
      link.setAttribute("aria-current", "page");
    } else {
      link.removeAttribute("aria-current");
    }
  });

  // 4. CHECK THAT IMPORTANT PAGE ELEMENTS EXIST
  const requiredElements = [
    "navigation",
    "menuToggle",
    "year"
  ];

  requiredElements.forEach(function (elementId) {
    if (!document.getElementById(elementId)) {
      console.warn(
        "Homepage element not found:",
        elementId
      );
    }
  });

  // 5. CONFIRM SCRIPT LOADED
  console.log(
    "Ali-Hikimah homepage JavaScript loaded successfully."
  );

});
