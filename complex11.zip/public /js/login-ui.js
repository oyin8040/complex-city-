
/* ==========================================
   ALI-HIKIMAH COMPLEX BUSINESS PLATFORM
   File: public/js/login-ui.js
   Purpose: Login page interface controls
========================================== */

"use strict";

document.addEventListener("DOMContentLoaded", () => {

  const loginForm = document.getElementById("loginForm");
  const loginIdentifier = document.getElementById("loginIdentifier");
  const passwordInput = document.getElementById("password");
  const togglePassword = document.getElementById("togglePassword");
  const rememberEmail = document.getElementById("rememberEmail");
  const loginMessage = document.getElementById("loginMessage");

  const SAVED_EMAIL_KEY = "aliHikimahSavedEmail";

  // Check that the login page elements exist.
  if (
    !loginForm ||
    !loginIdentifier ||
    !passwordInput ||
    !togglePassword
  ) {
    console.error("Login page elements are missing.");
    return;
  }

  // Show or hide password.
  togglePassword.addEventListener("click", () => {

    const isPasswordHidden =
      passwordInput.type === "password";

    passwordInput.type = isPasswordHidden
      ? "text"
      : "password";

    togglePassword.textContent = isPasswordHidden
      ? "Hide"
      : "Show";

    togglePassword.setAttribute(
      "aria-pressed",
      String(isPasswordHidden)
    );
  });

  // Restore saved email.
  try {
    const savedEmail = localStorage.getItem(SAVED_EMAIL_KEY);

    if (savedEmail) {
      loginIdentifier.value = savedEmail;

      if (rememberEmail) {
        rememberEmail.checked = true;
      }
    }
  } catch (error) {
    console.warn("Could not restore saved email.");
  }

  // Save email only when the checkbox is selected.
  loginForm.addEventListener("submit", () => {

    const identifier = loginIdentifier.value.trim();

    const isStaffId = /^STAFF[0-9]{6}$/i.test(identifier);

    try {
      if (rememberEmail && rememberEmail.checked && !isStaffId) {
        localStorage.setItem(
          SAVED_EMAIL_KEY,
          identifier
        );
      } else {
        localStorage.removeItem(SAVED_EMAIL_KEY);
      }
    } catch (error) {
      console.warn("Could not save login email.");
    }

  });

  // Clear old messages when the user edits the login details.
  if (loginMessage) {

    loginForm.addEventListener("input", () => {
      loginMessage.textContent = "";
      loginMessage.hidden = true;
      loginMessage.className = "form-message";
    });

  }

});
