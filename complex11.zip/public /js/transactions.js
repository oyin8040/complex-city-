/* ==========================================
   ALI-HIKIMAH TRANSACTION MANAGEMENT
   File: public/js/transactions.js
========================================== */

import {
  auth,
  db,
  onAuthStateChanged,
  doc,
  getDoc,
  collection,
  getDocs
} from "./firebase.js";

const $ = (id) => document.getElementById(id);

const businessNameElement = $("businessName");
const totalTransactionsElement = $("totalTransactions");
const todayTransactionsElement = $("todayTransactions");
const totalSalesElement = $("totalSales");

const transactionSearchInput = $("transactionSearch");
const startDateInput = $("startDate");
const endDateInput = $("endDate");
const paymentFilterInput = $("paymentFilter");

const transactionsTableBody = $("transactionsTableBody");
const transactionsMessage = $("transactionsMessage");

const transactionDetailsPanel = $("transactionDetailsPanel");
const detailTransactionId = $("detailTransactionId");
const detailDate = $("detailDate");
const detailCustomer = $("detailCustomer");
const detailPayment = $("detailPayment");
const detailTotal = $("detailTotal");
const transactionItemsBody = $("transactionItemsBody");
const closeDetailsButton = $("closeDetailsButton");

let currentUser = null;
let businessId = null;
let allTransactions = [];

/* ==========================================
   HELPERS
========================================== */

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function money(value) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 2
  }).format(Number(value) || 0);
}

function showMessage(message, type = "info") {
  if (!transactionsMessage) return;

  transactionsMessage.textContent = message;
  transactionsMessage.className = `message ${type}`;
  transactionsMessage.hidden = false;
}

function clearMessage() {
  if (!transactionsMessage) return;

  transactionsMessage.textContent = "";
  transactionsMessage.hidden = true;
}

function toDate(value) {
  if (!value) return null;

  if (typeof value.toDate === "function") {
    return value.toDate();
  }

  if (value instanceof Date) {
    return value;
  }

  if (typeof value.seconds === "number") {
    return new Date(value.seconds * 1000);
  }

  return null;
}

function formatDate(value) {
  const date = toDate(value);

  return date
    ? date.toLocaleString("en-NG", {
        dateStyle: "medium",
        timeStyle: "short"
      })
    : "Date unavailable";
}

function isToday(value) {
  const date = toDate(value);
  if (!date) return false;

  const now = new Date();

  return date.getFullYear() === now.getFullYear()
    && date.getMonth() === now.getMonth()
    && date.getDate() === now.getDate();
}

/* ==========================================
   LOAD BUSINESS PROFILE
========================================== */

async function loadBusinessProfile(user) {
  const businessRef = doc(db, "businesses", user.uid);
  const snapshot = await getDoc(businessRef);

  if (!snapshot.exists()) {
    throw new Error("Business profile was not found.");
  }

  const business = snapshot.data();

  if (
    business.ownerUid !== user.uid ||
    business.businessId !== user.uid
  ) {
    throw new Error("Business ownership verification failed.");
  }

  businessId = user.uid;

  if (businessNameElement) {
    businessNameElement.textContent =
      business.businessName || "My Business";
  }
}

/* ==========================================
   LOAD TRANSACTIONS
========================================== */

async function loadTransactions() {
  const transactionsRef = collection(
    db,
    "businesses",
    businessId,
    "transactions"
  );

  const snapshot = await getDocs(transactionsRef);

  allTransactions = snapshot.docs
    .map((transactionDoc) => ({
      id: transactionDoc.id,
      ...transactionDoc.data()
    }))
    .filter((transaction) =>
      transaction.ownerUid === currentUser.uid &&
      transaction.businessId === businessId &&
      transaction.status === "completed"
    )
    .sort((a, b) => {
      const dateA = toDate(a.createdAt)?.getTime() || 0;
      const dateB = toDate(b.createdAt)?.getTime() || 0;
      return dateB - dateA;
    });

  renderSummary();
  applyFilters();
}

/* ==========================================
   SUMMARY CARDS
========================================== */

function renderSummary() {
  const todayTransactions = allTransactions.filter(
    (transaction) => isToday(transaction.createdAt)
  );

  const todaySales = todayTransactions.reduce(
    (sum, transaction) =>
      sum + (Number(transaction.totalAmount) || 0),
    0
  );

  if (totalTransactionsElement) {
    totalTransactionsElement.textContent =
      String(allTransactions.length);
  }

  if (todayTransactionsElement) {
    todayTransactionsElement.textContent =
      String(todayTransactions.length);
  }

  if (totalSalesElement) {
    totalSalesElement.textContent = money(todaySales);
  }
}

/* ==========================================
   FILTER TRANSACTIONS
========================================== */

function applyFilters() {
  const query =
    transactionSearchInput?.value.trim().toLowerCase() || "";

  const startValue = startDateInput?.value || "";
  const endValue = endDateInput?.value || "";
  const payment = paymentFilterInput?.value || "";

  const start = startValue
    ? new Date(`${startValue}T00:00:00`)
    : null;

  const end = endValue
    ? new Date(`${endValue}T23:59:59.999`)
    : null;

  const filtered = allTransactions.filter((transaction) => {
    const customer = String(
      transaction.customerName || ""
    ).toLowerCase();

    const id = String(
      transaction.transactionId || transaction.id
    ).toLowerCase();

    const method = String(
      transaction.paymentMethod || ""
    ).toLowerCase();

    const transactionDate = toDate(transaction.createdAt);

    if (
      query &&
      !customer.includes(query) &&
      !id.includes(query)
    ) {
      return false;
    }

    if (payment && method !== payment.toLowerCase()) {
      return false;
    }

    if (start && (!transactionDate || transactionDate < start)) {
      return false;
    }

    if (end && (!transactionDate || transactionDate > end)) {
      return false;
    }

    return true;
  });

  renderTransactions(filtered);
}

/* ==========================================
   TRANSACTION TABLE
========================================== */

function renderTransactions(transactions) {
  if (!transactionsTableBody) return;

  if (!transactions.length) {
    transactionsTableBody.innerHTML = `
      <tr>
        <td colspan="6">No transactions match your filters.</td>
      </tr>
    `;
    return;
  }

  transactionsTableBody.innerHTML = transactions.map(
    (transaction) => `
      <tr>
        <td>${escapeHTML(
          transaction.transactionId || transaction.id
        )}</td>
        <td>${escapeHTML(formatDate(transaction.createdAt))}</td>
        <td>${escapeHTML(
          transaction.customerName || "Walk-in customer"
        )}</td>
        <td>${escapeHTML(transaction.paymentMethod || "N/A")}</td>
        <td>${money(transaction.totalAmount)}</td>
        <td>
          <button
            type="button"
            data-view-transaction="${escapeHTML(transaction.id)}"
          >
            View
          </button>
        </td>
      </tr>
    `
  ).join("");
}

/* ==========================================
   TRANSACTION DETAILS
========================================== */

function showTransactionDetails(transactionId) {
  const transaction = allTransactions.find(
    (item) => item.id === transactionId
  );

  if (!transaction) {
    showMessage("Transaction could not be found.", "error");
    return;
  }

  if (detailTransactionId) {
    detailTransactionId.textContent =
      transaction.transactionId || transaction.id;
  }

  if (detailDate) {
    detailDate.textContent = formatDate(transaction.createdAt);
  }

  if (detailCustomer) {
    detailCustomer.textContent =
      transaction.customerName || "Walk-in customer";
  }

  if (detailPayment) {
    detailPayment.textContent =
      transaction.paymentMethod || "N/A";
  }

  if (detailTotal) {
    detailTotal.textContent = money(transaction.totalAmount);
  }

  if (transactionItemsBody) {
    const items = Array.isArray(transaction.items)
      ? transaction.items
      : [];

    transactionItemsBody.innerHTML = items.length
      ? items.map((item) => `
          <tr>
            <td>${escapeHTML(item.productName || "Product")}</td>
            <td>${Number(item.quantity) || 0}</td>
            <td>${money(item.sellingPrice)}</td>
            <td>${money(item.lineTotal)}</td>
          </tr>
        `).join("")
      : '<tr><td colspan="4">No item details available.</td></tr>';
  }

  if (transactionDetailsPanel) {
    transactionDetailsPanel.hidden = false;
    transactionDetailsPanel.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  }

  clearMessage();
}

/* ==========================================
   EVENT LISTENERS
========================================== */

[
  transactionSearchInput,
  startDateInput,
  endDateInput,
  paymentFilterInput
].forEach((element) => {
  if (!element) return;

  element.addEventListener("input", applyFilters);
  element.addEventListener("change", applyFilters);
});

if (transactionsTableBody) {
  transactionsTableBody.addEventListener("click", (event) => {
    const button = event.target.closest("[data-view-transaction]");
    if (!button) return;

    showTransactionDetails(button.dataset.viewTransaction);
  });
}

if (closeDetailsButton) {
  closeDetailsButton.addEventListener("click", () => {
    if (transactionDetailsPanel) {
      transactionDetailsPanel.hidden = true;
    }
  });
}

/* ==========================================
   AUTHENTICATION AND INITIALIZATION
========================================== */

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "login.html";
    return;
  }

  currentUser = user;

  try {
    showMessage("Loading transaction history...", "info");

    await loadBusinessProfile(user);
    await loadTransactions();

    clearMessage();
  } catch (error) {
    console.error("[TRANSACTIONS DEBUG]", error);

    showMessage(
      `Could not load transactions: ${
        error?.code || error?.message || "Unknown error"
      }`,
      "error"
    );
  }
});