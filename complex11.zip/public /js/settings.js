
"use strict";

import {
  auth,
  db,
  onAuthStateChanged,
  signOut,
  doc,
  getDoc,
  updateDoc,
  serverTimestamp
} from "./firebase.js";

/* =========================================
   ALI-HIKIMAH BUSINESS SETTINGS
   File: public/js/settings.js
========================================= */

const $ = (id) => document.getElementById(id);

const businessForm = $("businessSettingsForm");
const saveBusinessButton = $("saveBusinessSettingsButton");
const savePreferencesButton = $("savePreferencesButton");
const messageBox = $("settingsMessage");
const logoutButton = $("logoutButton");

let currentUser = null;
let currentBusiness = null;
let isSavingBusiness = false;
let isSavingPreferences = false;

/* ---------- Messages ---------- */

function showMessage(message, type = "error") {
  if (!messageBox) return;

  messageBox.textContent = message;
  messageBox.dataset.type = type;
  messageBox.hidden = false;
}

function hideMessage() {
  if (!messageBox) return;

  messageBox.textContent = "";
  messageBox.hidden = true;
  delete messageBox.dataset.type;
}

/* ---------- Display helpers ---------- */

function setText(id, value) {
  const element = $(id);

  if (element) {
    element.textContent = value ?? "";
  }
}

function setAvatar(id, name) {
  const element = $(id);

  if (!element) return;

  const firstLetter = String(name || "O")
    .trim()
    .charAt(0)
    .toUpperCase();

  element.textContent = firstLetter || "O";
}

function formatDate(value) {
  if (!value) return "Not available";

  let date;

  if (typeof value.toDate === "function") {
    date = value.toDate();
  } else {
    date = new Date(value);
  }

  if (Number.isNaN(date.getTime())) {
    return "Not available";
  }

  return date.toLocaleDateString("en-NG", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

function formatStatus(status) {
  if (!status) return "Unknown";

  return String(status)
    .replaceAll("_", " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function clearBusinessSession() {
  sessionStorage.removeItem("businessId");
  sessionStorage.removeItem("businessName");
  sessionStorage.removeItem("businessStatus");
  sessionStorage.removeItem("accountType");
}

/* ---------- Category handling ---------- */

function setCategoryValue(category) {
  const select = $("settingsCategory");

  if (!select) return;

  const value = String(category || "");

  if (!value) {
    select.value = "";
    return;
  }

  const matchingOption = Array.from(select.options).find(
    (option) => option.value === value
  );

  // Preserve an existing category even if it is not
  // one of the currently listed standard categories.
  if (!matchingOption) {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
  }

  select.value = value;
}

/* ---------- Load business settings ---------- */

async function loadSettings(user) {
  console.log("[SETTINGS] Loading business settings.");

  const businessRef = doc(db, "businesses", user.uid);
  const ownerRef = doc(db, "users", user.uid);

  const businessSnapshot = await getDoc(businessRef);

  if (!businessSnapshot.exists()) {
    throw new Error(
      "Your business account could not be found. Please contact support."
    );
  }

  const business = businessSnapshot.data();

  // Verify that this signed-in user owns this business.
  if (
    business.ownerUid !== user.uid ||
    business.businessId !== user.uid
  ) {
    throw new Error(
      "Your account could not be verified as the owner of this business."
    );
  }

  if (["suspended", "disabled"].includes(business.status)) {
    throw new Error(
      "This business account is restricted. Please contact support."
    );
  }

  const ownerSnapshot = await getDoc(ownerRef);
  const owner = ownerSnapshot.exists()
    ? ownerSnapshot.data()
    : {};

  currentUser = user;
  currentBusiness = business;

  const ownerName =
    owner.fullName ||
    business.ownerName ||
    user.displayName ||
    "Business Owner";

  const ownerEmail =
    owner.email ||
    business.ownerEmail ||
    user.email ||
    "Not provided";

  const businessName =
    business.businessName || "My Business";

  const category =
    business.category || "Not specified";

  const location =
    business.location || "";

  // Fill the editable form.
  setText("settingsBusinessName", businessName);
  setCategoryValue(business.category || "");
  setText("settingsLocation", location);

  const businessNameInput = $("settingsBusinessName");
  const locationInput = $("settingsLocation");

  if (businessNameInput) {
    businessNameInput.value =
      business.businessName || "";
  }

  if (locationInput) {
    locationInput.value = location;
  }

  // Fill account information.
  setText("settingsBusinessId", business.businessId);
  setText("settingsOwnerName", ownerName);
  setText("settingsOwnerEmail", ownerEmail);
  setText(
    "settingsAccountStatus",
    formatStatus(business.status)
  );
  setText(
    "settingsCreatedAt",
    formatDate(business.createdAt)
  );

  // Fill dashboard identity.
  setText("businessName", businessName);
  setText("businessCategory", category);
  setText("ownerName", ownerName);
  setText("accountStatus", formatStatus(business.status));

  setAvatar("businessAvatar", businessName);
  setAvatar("ownerAvatar", ownerName);
  setAvatar("topbarAvatar", ownerName);

  // Keep the existing session context in sync.
  sessionStorage.setItem("businessId", business.businessId);
  sessionStorage.setItem("businessName", businessName);
  sessionStorage.setItem(
    "businessStatus",
    business.status || "unknown"
  );
  sessionStorage.setItem("accountType", "owner");

  loadPreferences();

  hideMessage();

  console.log("[SETTINGS] Business settings loaded.");
}

/* ---------- Save business details ---------- */

async function saveBusinessSettings(event) {
  event.preventDefault();

  if (isSavingBusiness || !currentUser || !currentBusiness) {
    return;
  }

  hideMessage();

  const businessName = $("settingsBusinessName").value.trim();
  const category = $("settingsCategory").value.trim();
  const location = $("settingsLocation").value.trim();

  if (businessName.length < 2) {
    showMessage("Enter a business name with at least 2 characters.");
    return;
  }

  if (!category) {
    showMessage("Please select a business category.");
    return;
  }

  if (location.length < 2) {
    showMessage("Enter your business location.");
    return;
  }

  isSavingBusiness = true;

  if (saveBusinessButton) {
    saveBusinessButton.disabled = true;
    saveBusinessButton.textContent = "Saving...";
  }

  try {
    const businessRef = doc(
      db,
      "businesses",
      currentUser.uid
    );

    await updateDoc(businessRef, {
      businessName,
      category,
      location,
      updatedAt: serverTimestamp()
    });

    // Update the page only after Firebase confirms the save.
    currentBusiness = {
      ...currentBusiness,
      businessName,
      category,
      location
    };

    setText("businessName", businessName);
    setText("businessCategory", category);
    setAvatar("businessAvatar", businessName);

    sessionStorage.setItem("businessName", businessName);

    showMessage(
      "Business details saved successfully.",
      "success"
    );

    console.log("[SETTINGS] Business details saved.");

  } catch (error) {
    console.error("[SETTINGS] Save failed:", error);

    if (
      error.code === "permission-denied" ||
      error.code === "firestore/permission-denied"
    ) {
      showMessage(
        "Firebase denied this update. We will review the Firestore Rules during the final security pass."
      );
    } else if (!navigator.onLine) {
      showMessage(
        "You appear to be offline. Check your internet connection and try again."
      );
    } else {
      showMessage(
        "Business details could not be saved. Please try again."
      );
    }

  } finally {
    isSavingBusiness = false;

    if (saveBusinessButton) {
      saveBusinessButton.disabled = false;
      saveBusinessButton.textContent = "Save Business Details";
    }
  }
}

/* ---------- Workspace preferences ---------- */

const PREFERENCES_KEY = "aliHikimahWorkspacePreferences";

function loadPreferences() {
  let preferences = {};

  try {
    preferences = JSON.parse(
      localStorage.getItem(PREFERENCES_KEY) || "{}"
    );
  } catch (error) {
    console.warn("[SETTINGS] Preferences could not be read.");
  }

  const unsavedToggle = $("confirmUnsavedChanges");
  const stockToggle = $("enableLowStockReminders");

  if (unsavedToggle) {
    unsavedToggle.checked =
      preferences.confirmUnsavedChanges !== false;
  }

  if (stockToggle) {
    stockToggle.checked =
      preferences.enableLowStockReminders !== false;
  }
}

function savePreferences() {
  if (isSavingPreferences) return;

  hideMessage();

  const preferences = {
    confirmUnsavedChanges:
      $("confirmUnsavedChanges")?.checked ?? true,

    enableLowStockReminders:
      $("enableLowStockReminders")?.checked ?? true
  };

  isSavingPreferences = true;

  if (savePreferencesButton) {
    savePreferencesButton.disabled = true;
    savePreferencesButton.textContent = "Saving...";
  }

  try {
    localStorage.setItem(
      PREFERENCES_KEY,
      JSON.stringify(preferences)
    );

    showMessage(
      "Workspace preferences saved in this browser.",
      "success"
    );

    console.log("[SETTINGS] Workspace preferences saved.");

  } catch (error) {
    console.error("[SETTINGS] Preference save failed:", error);

    showMessage(
      "Preferences could not be saved in this browser. Check available storage."
    );

  } finally {
    isSavingPreferences = false;

    if (savePreferencesButton) {
      savePreferencesButton.disabled = false;
      savePreferencesButton.textContent = "Save Preferences";
    }
  }
}

/* ---------- Sign out ---------- */

async function handleLogout() {
  if (!currentUser) {
    window.location.replace("login.html");
    return;
  }

  if (logoutButton) {
    logoutButton.disabled = true;
    logoutButton.textContent = "Signing out...";
  }

  try {
    await signOut(auth);
    clearBusinessSession();
    window.location.replace("login.html");

  } catch (error) {
    console.error("[SETTINGS] Sign-out failed:", error);

    showMessage(
      "Sign-out failed. Please check your connection and try again."
    );

    if (logoutButton) {
      logoutButton.disabled = false;
      logoutButton.textContent = "↪ Sign Out";
    }
  }
}

/* ---------- Event listeners ---------- */

if (businessForm) {
  businessForm.addEventListener(
    "submit",
    saveBusinessSettings
  );
}

if (savePreferencesButton) {
  savePreferencesButton.addEventListener(
    "click",
    savePreferences
  );
}

if (logoutButton) {
  logoutButton.addEventListener(
    "click",
    handleLogout
  );
}

/* ---------- Authentication ---------- */

let authCheckStarted = false;

onAuthStateChanged(auth, async (user) => {
  if (authCheckStarted) return;

  authCheckStarted = true;

  if (!user) {
    clearBusinessSession();
    window.location.replace("login.html");
    return;
  }

  try {
    await loadSettings(user);

  } catch (error) {
    console.error("[SETTINGS] Page initialization failed:", error);

    if (
      error.code === "permission-denied" ||
      error.code === "firestore/permission-denied"
    ) {
      showMessage(
        "Firebase denied access to your business information. We will review the Firestore Rules during the final security pass."
      );
    } else {
      showMessage(
        error.message ||
        "Business settings could not be loaded."
      );
    }
  }
});
