
/* ==========================================
   ALI-HIKIMAH COMPLEX BUSINESS MANAGEMENT
   File: public/js/firebase.js
========================================== */

import {
  initializeApp
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-app.js";

import {
  getAuth,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithCustomToken,
  updateProfile,
  signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";

import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  updateDoc,
  serverTimestamp,
  collection,
  addDoc,
  getDocs,
  runTransaction
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";

/* ==========================================
   FIREBASE CONFIGURATION
========================================== */

const firebaseConfig = {
  apiKey: "AIzaSyDw62dP8aTVd8p9xlMX26JJnzYlRa-9RtE",
  authDomain: "pro5-1858c.firebaseapp.com",
  projectId: "pro5-1858c",
  storageBucket: "pro5-1858c.firebasestorage.app",
  messagingSenderId: "769946712534",
  appId: "1:769946712534:web:84762baef002b676d4cc77"
};

/* ==========================================
   INITIALIZE FIREBASE
========================================== */

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const db = getFirestore(app);

/* ==========================================
   EXPORT SHARED FIREBASE FUNCTIONS
========================================== */

export {
  auth,
  db,

  // Authentication
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithCustomToken,
  updateProfile,
  signOut,
  onAuthStateChanged,

  // Firestore documents
  doc,
  setDoc,
  getDoc,
  updateDoc,

  // Firestore collections
  collection,
  addDoc,
  getDocs,

  // Timestamps and atomic transactions
  serverTimestamp,
  runTransaction
};
