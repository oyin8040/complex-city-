
"use strict";

import {
  auth,
  db,
  onAuthStateChanged,
  doc,
  getDoc
} from "./firebase.js";

const $ = (id) => document.getElementById(id);

function showMessage(message, type = "error") {
  const box = $("profileMessage");

  if (box) {
    box.hidden = false;
    box.textContent = message;
    box.className = "dashboard-message " + type;
  }

  console.log("[PROFILE]", message);
}

function hideMessage() {
  const box = $("profileMessage");

  if (box) {
    box.hidden = true;
    box.textContent = "";
  }
}

function setText(id, value) {
  const element = $(id);

  if (element) {
    element.textContent =
      value === null || value === undefined || value === ""
        ? "Not provided"
        : String(value);
  }
}

function formatDate(value) {
  if (!value) return "Not available";

  try {
    const date = typeof value.toDate === "function"
      ? value.toDate()
      : new Date(value);

    if (Number.isNaN(date.getTime())) {
      return "Not available";
    }

    return date.toLocaleDateString("en-NG", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });
  } catch {
    return "Not available";
  }
}

function statusLabel(status) {
  const labels = {
    pending_setup: "Pending Setup",
    active: "Active",
    suspended: "Suspended",
    disabled: "Disabled"
  };

  return labels[status] || status || "Unknown";
}

function setAvatar(id, name) {
  const initial = String(name || "?")
    .trim()
    .charAt(0)
    .toUpperCase() || "?";

  setText(id, initial);
}

async function loadProfile(user) {
  console.log("[PROFILE] Loading owner profile for:", user.uid);

  const businessRef = doc(db, "businesses", user.uid);
  const ownerRef = doc(db, "users", user.uid);

  // Load the business record first.
  const businessSnapshot = await getDoc(businessRef);

  if (!businessSnapshot.exists()) {
    throw new Error(
      "Your business record was not found. Please contact support."
    );
  }

  const business = businessSnapshot.data();

  // Verify that this business belongs to the signed-in owner.
  if (
    business.ownerUid !== user.uid ||
    business.businessId !== user.uid
  ) {
    throw new Error(
      "Your business ownership could not be verified."
    );
  }

  // The owner document may be missing, so use safe fallbacks.
  const ownerSnapshot = await getDoc(ownerRef);
  const owner = ownerSnapshot.exists()
    ? ownerSnapshot.data()
    : {};

  const name =
    owner.fullName ||
    business.ownerName ||
    user.displayName ||
    "Business Owner";

  const email =
    owner.email ||
    business.ownerEmail ||
    user.email ||
    "Not provided";

  const phone =
    owner.phone ||
    business.ownerPhone ||
    "Not provided";

  const businessName =
    business.businessName || "My Business";

  // Owner information.
  setText("ownerFullName", name);
  setText("ownerEmail", email);
  setText("ownerPhone", phone);
  setText("profileWelcomeName", name);
  setText("sidebarOwnerName", name);

  // Business information.
  setText("profileBusinessName", businessName);
  setText("profileBusinessId", business.businessId);
  setText("profileBusinessCategory", business.category);
  setText("profileBusinessLocation", business.location);
  setText("profileBusinessStatus", statusLabel(business.status));
  setText("profileCreatedAt", formatDate(business.createdAt));
  setText("profileOwnerUid", user.uid);

  // Sidebar information.
  setText("sidebarBusinessName", businessName);
  setText(
    "sidebarBusinessCategory",
    business.category || "Business"
  );

  // Avatars and account status.
  setAvatar("ownerAvatar", name);
  setAvatar("topbarAvatar", name);
  setAvatar("businessAvatar", businessName);
  setText("accountStatus", statusLabel(business.status));

  // Keep session information for display only.
  sessionStorage.setItem("businessId", business.businessId);
  sessionStorage.setItem("businessName", businessName);
  sessionStorage.setItem("businessStatus", business.status || "unknown");
  sessionStorage.setItem("accountType", "owner");

  if (ownerSnapshot.exists()) {
    console.log("[PROFILE] Owner and business information loaded.");
  } else {
    console.warn(
      "[PROFILE] Owner document is missing. Fallback details were used."
    );
  }

  hideMessage();
  console.log("[PROFILE] Profile loading completed.");
}

// Authentication listener must be outside loadProfile().
let profileCheckStarted = false;

onAuthStateChanged(auth, async (user) => {
  if (profileCheckStarted) return;
  profileCheckStarted = true;

  if (!user) {
    sessionStorage.removeItem("businessId");
    sessionStorage.removeItem("businessName");
    sessionStorage.removeItem("businessStatus");
    sessionStorage.removeItem("accountType");

    window.location.replace("login.html");
    return;
  }

  try {
    await loadProfile(user);
  } catch (error) {
    console.error("[PROFILE] Loading failed:", error);

    showMessage(
      error.code === "permission-denied"
        ? "Access denied. Please check your database permissions."
        : error.message || "Unable to load your owner profile.",
      "error"
    );
  }
});
