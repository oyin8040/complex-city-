
"use strict";

document.addEventListener("DOMContentLoaded", () => {
  const sidebar = document.getElementById("sidebar");
  const menuToggle = document.getElementById("menuToggle");
  const sidebarOverlay = document.getElementById("sidebarOverlay");

  if (!sidebar || !menuToggle || !sidebarOverlay) {
    console.warn("Dashboard menu elements were not found.");
    return;
  }

  function openSidebar() {
    sidebar.classList.add("is-open");
    sidebarOverlay.hidden = false;
    menuToggle.setAttribute("aria-expanded", "true");
    document.body.classList.add("sidebar-open");
  }

  function closeSidebar() {
    sidebar.classList.remove("is-open");
    sidebarOverlay.hidden = true;
    menuToggle.setAttribute("aria-expanded", "false");
    document.body.classList.remove("sidebar-open");
  }

  menuToggle.setAttribute("aria-expanded", "false");

  menuToggle.addEventListener("click", () => {
    if (sidebar.classList.contains("is-open")) {
      closeSidebar();
    } else {
      openSidebar();
    }
  });

  sidebarOverlay.addEventListener("click", closeSidebar);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeSidebar();
    }
  });

  sidebar.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      closeSidebar();
    });
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth > 760) {
      closeSidebar();
    }
  });
});
