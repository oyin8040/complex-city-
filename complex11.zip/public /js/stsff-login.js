
"use strict";

import { auth } from "./firebase.js";

import {
  signInWithCustomToken,
  signOut
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";

// ======================================
// 1. GET PAGE ELEMENTS
// ======================================

const loginForm = document.getElementById("staffLoginForm");
const staffIdInput = document.getElementById("staffId");
const passwordInput = document.getElementById("staffPassword");
const togglePassword = document.getElementById("togglePassword");
const capsWarning = document.getElementById("capsWarning");
const loginButton = document.getElementById("staffLoginButton");
const loginMessage = document.getElementById("staffLoginMessage");

// ======================================
// 2. DISPLAY LOGIN MESSAGES
// ======================================

function showMessage(message, type = "error") {
  loginMessage.textContent = message;
  loginMessage.className = `message show ${type}`;
}

function clearMessage() {
  loginMessage.textContent = "";
  loginMessage.className = "message";
}

// ======================================
// 3. SHOW OR HIDE PASSWORD
// ======================================

togglePassword.addEventListener("click", () => {
  const isHidden = passwordInput.type === "password";

  passwordInput.type = isHidden ? "text" : "password";
  togglePassword.textContent = isHidden ? "Hide" : "Show";
});

// ======================================
// 4. CAPS LOCK WARNING
// ======================================

passwordInput.addEventListener("keyup", (event) => {
  capsWarning.classList.toggle(
    "show",
    event.getModifierState("CapsLock")
  );
});

passwordInput.addEventListener("blur", () => {
  capsWarning.classList.remove("show");
});

// ======================================
// 5. NORMALIZE STAFF ID
// ======================================

staffIdInput.addEventListener("input", () => {
  staffIdInput.value = staffIdInput.value
    .trim()
    .toUpperCase()
    .replace(/\s/g, "");

  clearMessage();
});

// ======================================
// 6. PREVENT MULTIPLE LOGIN REQUESTS
// ======================================

function setLoading(isLoading) {
  loginButton.disabled = isLoading;
  loginButton.textContent = isLoading
    ? "Signing in..."
    : "Sign In";
}

// ======================================
// 7. STAFF LOGIN
// ======================================

loginForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  clearMessage();

  const staffId = staffIdInput.value.trim().toUpperCase();
  const password = passwordInput.value;

  if (!/^STAFF[0-9]{6}$/.test(staffId)) {
    showMessage("Enter a valid Staff ID.");
    staffIdInput.focus();
    return;
  }

  if (!password) {
    showMessage("Please enter your password.");
    passwordInput.focus();
    return;
  }

  setLoading(true);

  try {
    // Clear any previous login session.
    await signOut(auth);

    // Send credentials to the secure server.
    const response = await fetch("/api/staff/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        staffId,
        password
      })
    });

    const result = await response.json();

    if (!response.ok || !result.success) {
      throw new Error(
        result.message || "Login failed. Check your details."
      );
    }

    // The server must return a Firebase CUSTOM token.
    if (!result.customToken) {
      throw new Error(
        "The authentication server returned an invalid login response."
      );
    }

    // Establish the staff Firebase session.
    const credential = await signInWithCustomToken(
      auth,
      result.customToken
    );

    const staff = result.staff || {};

    // Store permitted staff session information.
    sessionStorage.setItem("accountType", "staff");
    sessionStorage.setItem("staffUid", credential.user.uid);
    sessionStorage.setItem("staffId", staff.staffId || staffId);
    sessionStorage.setItem("staffName", staff.name || "");
    sessionStorage.setItem("staffRole", staff.role || "cashier");
    sessionStorage.setItem("businessId", staff.businessId || "");
    sessionStorage.setItem("businessName", staff.businessName || "");

    showMessage("Login successful. Opening your dashboard...", "success");

    // Open the staff sales dashboard.
    window.location.replace("sales-dashboard.html");

  } catch (error) {
    console.error("Staff login error:", error);

    await signOut(auth).catch(() => {});

    sessionStorage.clear();

    showMessage(
      error.message || "Unable to sign in. Please try again."
    );

    passwordInput.value = "";
    passwordInput.focus();

  } finally {
    setLoading(false);
  }
});
