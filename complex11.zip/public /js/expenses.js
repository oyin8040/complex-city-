/* ==========================================
   ALI-HIKIMAH EXPENSE MANAGEMENT
   File: public/js/expenses.js
========================================== */

import {
  auth,
  db,
  onAuthStateChanged,
  doc,
  getDoc,
  collection,
  addDoc,
  getDocs,
  serverTimestamp
} from "./firebase.js";

const $ = (id) => document.getElementById(id);

const businessNameElement = $("businessName");

const todayExpensesElement = $("todayExpenses");
const monthlyExpensesElement = $("monthlyExpenses");
const totalExpensesElement = $("totalExpenses");

const expenseForm = $("expenseForm");
const expenseTitleInput = $("expenseTitle");
const expenseCategoryInput = $("expenseCategory");
const expenseAmountInput = $("expenseAmount");
const expenseDateInput = $("expenseDate");
const expensePaymentInput = $("expensePayment");
const expenseReferenceInput = $("expenseReference");
const expenseNotesInput = $("expenseNotes");
const saveExpenseButton = $("saveExpenseButton");
const expenseMessage = $("expenseMessage");

const expenseSearchInput = $("expenseSearch");
const expenseFilterCategoryInput = $("expenseFilterCategory");
const expensesTableBody = $("expensesTableBody");

let currentUser = null;
let businessId = null;
let allExpenses = [];
let savingExpense = false;

/* ==========================================
   HELPERS
========================================== */

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[character]);
}

function money(value) {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 2
  }).format(Number(value) || 0);
}

function showMessage(message, type = "info") {
  if (!expenseMessage) return;

  expenseMessage.textContent = message;
  expenseMessage.className = `message ${type}`;
  expenseMessage.hidden = false;
}

function clearMessage() {
  if (!expenseMessage) return;

  expenseMessage.textContent = "";
  expenseMessage.hidden = true;
}

function toDate(value) {
  if (!value) return null;

  if (typeof value.toDate === "function") {
    return value.toDate();
  }

  if (value instanceof Date) {
    return value;
  }

  if (typeof value.seconds === "number") {
    return new Date(value.seconds * 1000);
  }

  if (typeof value === "string") {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  return null;
}

function formatDate(value) {
  const date = toDate(value);

  return date
    ? date.toLocaleDateString("en-NG", {
        day: "2-digit",
        month: "short",
        year: "numeric"
      })
    : "Date unavailable";
}

function dateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");

  return `${year}-${month}-${day}`;
}

function setSaveBusy(busy) {
  if (!saveExpenseButton) return;

  saveExpenseButton.disabled = busy;
  saveExpenseButton.textContent = busy
    ? "Saving expense..."
    : "Save Expense";
}

/* ==========================================
   LOAD BUSINESS PROFILE
========================================== */

async function loadBusinessProfile(user) {
  const businessRef = doc(db, "businesses", user.uid);
  const snapshot = await getDoc(businessRef);

  if (!snapshot.exists()) {
    throw new Error("Business profile was not found.");
  }

  const business = snapshot.data();

  if (
    business.ownerUid !== user.uid ||
    business.businessId !== user.uid
  ) {
    throw new Error("Business ownership verification failed.");
  }

  businessId = user.uid;

  if (businessNameElement) {
    businessNameElement.textContent =
      business.businessName || "My Business";
  }
}

/* ==========================================
   LOAD EXPENSES
========================================== */

async function loadExpenses() {
  const expensesRef = collection(
    db,
    "businesses",
    businessId,
    "expenses"
  );

  const snapshot = await getDocs(expensesRef);

  allExpenses = snapshot.docs
    .map((expenseDoc) => ({
      id: expenseDoc.id,
      ...expenseDoc.data()
    }))
    .filter((expense) =>
      expense.ownerUid === currentUser.uid &&
      expense.businessId === businessId
    )
    .sort((a, b) => {
      const dateA = toDate(a.expenseDate)?.getTime() || 0;
      const dateB = toDate(b.expenseDate)?.getTime() || 0;

      return dateB - dateA;
    });

  renderSummary();
  applyFilters();
}

/* ==========================================
   SUMMARY CARDS
========================================== */

function renderSummary() {
  const now = new Date();
  const today = dateKey(now);

  const monthStart = new Date(
    now.getFullYear(),
    now.getMonth(),
    1
  );

  const todayTotal = allExpenses.reduce((sum, expense) => {
    const date = toDate(expense.expenseDate);

    return date && dateKey(date) === today
      ? sum + (Number(expense.amount) || 0)
      : sum;
  }, 0);

  const monthlyTotal = allExpenses.reduce((sum, expense) => {
    const date = toDate(expense.expenseDate);

    return date && date >= monthStart
      ? sum + (Number(expense.amount) || 0)
      : sum;
  }, 0);

  const overallTotal = allExpenses.reduce(
    (sum, expense) => sum + (Number(expense.amount) || 0),
    0
  );

  if (todayExpensesElement) {
    todayExpensesElement.textContent = money(todayTotal);
  }

  if (monthlyExpensesElement) {
    monthlyExpensesElement.textContent = money(monthlyTotal);
  }

  if (totalExpensesElement) {
    totalExpensesElement.textContent = money(overallTotal);
  }
}

/* ==========================================
   FILTER EXPENSES
========================================== */

function applyFilters() {
  const query =
    expenseSearchInput?.value.trim().toLowerCase() || "";

  const category = expenseFilterCategoryInput?.value || "";

  const filtered = allExpenses.filter((expense) => {
    const title = String(expense.title || "").toLowerCase();
    const reference = String(expense.reference || "").toLowerCase();
    const notes = String(expense.notes || "").toLowerCase();

    const matchesSearch =
      !query ||
      title.includes(query) ||
      reference.includes(query) ||
      notes.includes(query);

    const matchesCategory =
      !category || expense.category === category;

    return matchesSearch && matchesCategory;
  });

  renderExpenses(filtered);
}

/* ==========================================
   EXPENSE TABLE
========================================== */

function renderExpenses(expenses) {
  if (!expensesTableBody) return;

  if (!expenses.length) {
    expensesTableBody.innerHTML = `
      <tr>
        <td colspan="6">No expenses found.</td>
      </tr>
    `;
    return;
  }

  expensesTableBody.innerHTML = expenses.map((expense) => `
    <tr>
      <td>${escapeHTML(formatDate(expense.expenseDate))}</td>
      <td>${escapeHTML(expense.title || "Untitled expense")}</td>
      <td>${escapeHTML(expense.category || "Other")}</td>
      <td>${money(expense.amount)}</td>
      <td>${escapeHTML(expense.paymentMethod || "N/A")}</td>
      <td>${escapeHTML(expense.reference || "—")}</td>
    </tr>
  `).join("");
}

/* ==========================================
   SAVE EXPENSE
========================================== */

async function saveExpense(event) {
  event.preventDefault();

  if (savingExpense) return;

  if (!currentUser || !businessId) {
    showMessage("Please sign in again.", "error");
    return;
  }

  const title = expenseTitleInput?.value.trim() || "";
  const category = expenseCategoryInput?.value || "";
  const amount = Number(expenseAmountInput?.value);
  const expenseDate = expenseDateInput?.value || "";
  const paymentMethod = expensePaymentInput?.value || "";
  const reference = expenseReferenceInput?.value.trim() || "";
  const notes = expenseNotesInput?.value.trim() || "";

  const allowedCategories = [
    "rent",
    "utilities",
    "transport",
    "supplies",
    "salary",
    "maintenance",
    "marketing",
    "internet",
    "other"
  ];

  const allowedPayments = [
    "cash",
    "transfer",
    "pos",
    "other"
  ];

  if (!title || title.length > 120) {
    showMessage(
      "Enter an expense description of up to 120 characters.",
      "error"
    );
    return;
  }

  if (!allowedCategories.includes(category)) {
    showMessage("Select a valid expense category.", "error");
    return;
  }

  if (!Number.isFinite(amount) || amount <= 0) {
    showMessage("Enter an amount greater than zero.", "error");
    return;
  }

  if (!/^\d{4}-\d{2}-\d{2}$/.test(expenseDate)) {
    showMessage("Select a valid expense date.", "error");
    return;
  }

  if (!allowedPayments.includes(paymentMethod)) {
    showMessage("Select a valid payment method.", "error");
    return;
  }

  if (reference.length > 100 || notes.length > 500) {
    showMessage(
      "Reference must be 100 characters or less and notes 500 or less.",
      "error"
    );
    return;
  }

  savingExpense = true;
  setSaveBusy(true);
  clearMessage();

  try {
    const expensesRef = collection(
      db,
      "businesses",
      businessId,
      "expenses"
    );

    await addDoc(expensesRef, {
      ownerUid: currentUser.uid,
      businessId,
      title,
      category,
      amount,
      expenseDate,
      paymentMethod,
      reference,
      notes,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    expenseForm.reset();

    if (expenseDateInput) {
      expenseDateInput.value = dateKey(new Date());
    }

    showMessage("Expense saved successfully.", "success");

    await loadExpenses();
  } catch (error) {
    console.error("[EXPENSES DEBUG]", error);

    showMessage(
      `Could not save expense: ${
        error?.code || error?.message || "Unknown error"
      }`,
      "error"
    );
  } finally {
    savingExpense = false;
    setSaveBusy(false);
  }
}

/* ==========================================
   EVENT LISTENERS
========================================== */

if (expenseForm) {
  expenseForm.addEventListener("submit", saveExpense);
}

if (expenseSearchInput) {
  expenseSearchInput.addEventListener("input", applyFilters);
}

if (expenseFilterCategoryInput) {
  expenseFilterCategoryInput.addEventListener("change", applyFilters);
}

/* ==========================================
   AUTHENTICATION AND INITIALIZATION
========================================== */

if (expenseDateInput) {
  expenseDateInput.value = dateKey(new Date());
}

onAuthStateChanged(auth, async (user) => {
  if (!user) {
    window.location.href = "login.html";
    return;
  }

  currentUser = user;

  try {
    showMessage("Loading expenses...", "info");

    await loadBusinessProfile(user);
    await loadExpenses();

    clearMessage();
  } catch (error) {
    console.error("[EXPENSES DEBUG] Initialization failed", error);

    showMessage(
      `Could not load expenses: ${
        error?.code || error?.message || "Unknown error"
      }`,
      "error"
    );
  }
});