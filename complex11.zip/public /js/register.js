"use strict";

import {
  auth,
  db,
  createUserWithEmailAndPassword,
  updateProfile,
  doc,
  setDoc,
  serverTimestamp
} from "./firebase.js";

/* ==========================================
   ALI-HIKIMAH BUSINESS REGISTRATION
   File: public/js/register.js
========================================== */

const registerForm = document.getElementById("registerForm");
const registerMessage = document.getElementById("registerMessage");
const registerButton = document.getElementById("registerButton");

const BUSINESS_CATEGORIES = [
  "Pharmacy & Healthcare Retail",
  "Phone & Accessories",
  "Restaurant & Canteen",
  "Boutique & Fashion",
  "Supermarket & Grocery",
  "Cosmetics & Beauty",
  "Building Materials & Hardware",
  "Electronics & Appliances",
  "Wholesale & Distribution",
  "General Retail & Other"
];

/* ==========================================
   HELPERS
========================================== */

function showMessage(message, type = "info") {
  if (!registerMessage) return;

  registerMessage.textContent = message;
  registerMessage.className = `form-message ${type}`;
  registerMessage.hidden = false;
}

function getFriendlyError(error) {
  const code = error?.code || "";

  if (code === "auth/email-already-in-use") {
    return "This email already has an account. Please sign in.";
  }

  if (code === "auth/invalid-email") {
    return "Please enter a valid email address.";
  }

  if (code === "auth/weak-password") {
    return "Use a password containing at least 6 characters.";
  }

  if (code === "auth/network-request-failed") {
    return "Network error. Check your internet connection.";
  }

  if (
    code === "permission-denied" ||
    code === "firestore/permission-denied"
  ) {
    return "Firebase created or attempted your account, but the database refused a write. Check your Firestore rules before retrying.";
  }

  return error?.message || "An unexpected error occurred.";
}

function setRegisterBusy(busy) {
  if (!registerButton) return;

  registerButton.disabled = busy;
  registerButton.textContent = busy
    ? "Creating account..."
    : "Create Business Account";
}

/*
 * The authenticated owner's UID is the permanent internal
 * Business ID in this version of the platform.
 *
 * It is unique within Firebase Authentication and avoids
 * creating a separate, unverified business identifier.
 */

function createBusinessProfileId(user) {
  return user.uid;
}

/* ==========================================
   REGISTRATION
========================================== */

if (!registerForm) {
  console.error("Registration form #registerForm was not found.");
}

registerForm?.addEventListener("submit", async (event) => {
  event.preventDefault();

  if (!registerForm || !registerButton) return;

  const fullName =
    registerForm.elements.fullName?.value.trim() || "";

  const email =
    registerForm.elements.email?.value.trim().toLowerCase() || "";

  const phone =
    registerForm.elements.phone?.value.trim() || "";

  const password =
    registerForm.elements.password?.value || "";

  const confirmPassword =
    registerForm.elements.confirmPassword?.value || "";

  const businessName =
    registerForm.elements.businessName?.value.trim() || "";

  const category =
    registerForm.elements.category?.value || "";

  const location =
    registerForm.elements.location?.value.trim() || "";

  const agreeTerms =
    registerForm.elements.agreeTerms?.checked || false;

  /* Validate required fields */

  if (
    !fullName ||
    !email ||
    !phone ||
    !password ||
    !confirmPassword ||
    !businessName ||
    !category ||
    !location
  ) {
    showMessage("Please complete every required field.", "error");
    return;
  }

  if (fullName.length > 100) {
    showMessage("Your name must not exceed 100 characters.", "error");
    return;
  }

  if (businessName.length > 150) {
    showMessage("Your business name is too long.", "error");
    return;
  }

  if (phone.length > 30) {
    showMessage("Your phone number is too long.", "error");
    return;
  }

  if (location.length > 200) {
    showMessage("Your business location is too long.", "error");
    return;
  }

  if (password.length < 6) {
    showMessage(
      "Your password must contain at least 6 characters.",
      "error"
    );
    return;
  }

  if (password !== confirmPassword) {
    showMessage("Your passwords do not match.", "error");
    return;
  }

  if (!BUSINESS_CATEGORIES.includes(category)) {
    showMessage("Please select a valid business category.", "error");
    return;
  }

  if (!agreeTerms) {
    showMessage(
      "Please confirm that your information is correct.",
      "error"
    );
    return;
  }

  setRegisterBusy(true);
  showMessage("Creating your business account...", "info");

  let createdUser = null;
  let profileSaved = false;

  try {
    /* 1. Create the owner's authentication account */

    const credential = await createUserWithEmailAndPassword(
      auth,
      email,
      password
    );

    createdUser = credential.user;

    /* 2. Set the owner's display name */

    await updateProfile(createdUser, {
      displayName: fullName
    });

    /* 3. Assign the permanent Business ID */

    const businessId = createBusinessProfileId(createdUser);

    /* 4. Save the business profile */

    await setDoc(doc(db, "businesses", businessId), {
      businessId,
      ownerUid: createdUser.uid,
      ownerName: fullName,
      ownerEmail: email,
      ownerPhone: phone,
      businessName,
      category,
      location,
      status: "pending_setup",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    profileSaved = true;

    /* 5. Save the owner's user profile */

    await setDoc(doc(db, "users", createdUser.uid), {
      uid: createdUser.uid,
      fullName,
      email,
      phone,
      role: "owner",
      businessId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    /* 6. Continue to the private business login */

    showMessage(
      "Registration successful! Redirecting to sign in...",
      "success"
    );

    window.setTimeout(() => {
      window.location.href = "login.html";
    }, 1200);

  } catch (error) {
    console.error("Registration error:", {
      code: error?.code || "unknown",
      message: error?.message || String(error),
      ownerUid: createdUser?.uid || null,
      businessProfileSaved: profileSaved
    });

    if (createdUser && !profileSaved) {
      showMessage(
        "Your login account exists, but the business profile was not saved. Do not register again with this email. The database permissions or saved profile must be checked first.",
        "error"
      );
    } else if (createdUser && profileSaved) {
      showMessage(
        "Your business profile was saved, but the user profile could not be completed. Do not register again. Sign-in and profile recovery are needed.",
        "error"
      );
    } else {
      showMessage(getFriendlyError(error), "error");
    }

  } finally {
    setRegisterBusy(false);
  }
});