/* =====================================================
   ALI-HIKIMAH COMPLEX BUSINESS MANAGEMENT PLATFORM
   INVENTORY MODULE
   PART 1 OF 5
   Firebase, Authentication and Basic Setup
===================================================== */

import {
  db,
  auth
} from "./firebase.js";

import {
  collection,
  addDoc,
  getDocs,
  getDoc,
  doc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  query,
  orderBy
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-firestore.js";

import {
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.4.0/firebase-auth.js";


/* =====================================================
   1. GLOBAL VARIABLES
===================================================== */

let currentUser = null;

let businessId = null;

let businessData = {};

let products = [];

let editingProductId = null;

let html5QrCode = null;

let scannerRunning = false;


/* =====================================================
   2. HTML ELEMENT REFERENCES
===================================================== */

const businessNameElement =
  document.getElementById("businessName");

const businessCategoryElement =
  document.getElementById("businessCategory");

const totalProductsElement =
  document.getElementById("totalProducts");

const totalUnitsElement =
  document.getElementById("totalUnits");

const lowStockCountElement =
  document.getElementById("lowStockCount");

const totalStockValueElement =
  document.getElementById("totalStockValue");


/* PRODUCT FORM */

const productForm =
  document.getElementById("productForm");

const productNameInput =
  document.getElementById("productName");

const productCodeInput =
  document.getElementById("productCode");

const barcodeInput =
  document.getElementById("barcode");

const categoryInput =
  document.getElementById("category");

const quantityInput =
  document.getElementById("quantity");

const costPriceInput =
  document.getElementById("costPrice");

const sellingPriceInput =
  document.getElementById("sellingPrice");

const lowStockLevelInput =
  document.getElementById("lowStockLevel");

const unitInput =
  document.getElementById("unit");

const saveProductButton =
  document.getElementById("saveProductButton");

const inventoryMessage =
  document.getElementById("inventoryMessage");


/* CATEGORY FIELDS */

const categoryFields =
  document.getElementById("categoryFields");

const categoryFieldsContainer =
  document.getElementById("categoryFieldsContainer");

const productSuggestions =
  document.getElementById("productSuggestions");


/* SEARCH AND TABLE */

const productSearchInput =
  document.getElementById("productSearch");

const inventoryTableBody =
  document.getElementById("inventoryTableBody");


/* EDIT PRODUCT FORM */

const editProductPanel =
  document.getElementById("editProductPanel");

const editProductForm =
  document.getElementById("editProductForm");

const editProductIdInput =
  document.getElementById("editProductId");

const editProductNameInput =
  document.getElementById("editProductName");

const editProductCodeInput =
  document.getElementById("editProductCode");

const editBarcodeInput =
  document.getElementById("editBarcode");

const editCategoryInput =
  document.getElementById("editCategory");

const editQuantityInput =
  document.getElementById("editQuantity");

const editCostPriceInput =
  document.getElementById("editCostPrice");

const editSellingPriceInput =
  document.getElementById("editSellingPrice");

const editLowStockLevelInput =
  document.getElementById("editLowStockLevel");

const editUnitInput =
  document.getElementById("editUnit");

const editCategoryFields =
  document.getElementById("editCategoryFields");

const editCategoryFieldsContainer =
  document.getElementById("editCategoryFieldsContainer");

const updateProductButton =
  document.getElementById("updateProductButton");

const cancelEditButton =
  document.getElementById("cancelEditButton");

const editProductMessage =
  document.getElementById("editProductMessage");


/* BARCODE SCANNER */

const openBarcodeScannerButton =
  document.getElementById("openBarcodeScanner");

const barcodeScannerPanel =
  document.getElementById("barcodeScannerPanel");

const barcodeReader =
  document.getElementById("barcodeReader");

const barcodeScannerMessage =
  document.getElementById("barcodeScannerMessage");

const stopBarcodeScannerButton =
  document.getElementById("stopBarcodeScanner");

const manualBarcodeInput =
  document.getElementById("manualBarcode");

const useManualBarcodeButton =
  document.getElementById("useManualBarcode");


/* =====================================================
   3. GENERAL HELPER FUNCTIONS
===================================================== */

function formatMoney(amount) {

  const value = Number(amount) || 0;

  return "₦" + value.toLocaleString("en-NG", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });

}


function showMessage(element, message, type = "info") {

  if (!element) return;

  element.textContent = message;

  element.className = "message " + type;

}


function clearMessage(element) {

  if (!element) return;

  element.textContent = "";

  element.className = "";

}


function getNumber(value) {

  const number = Number(value);

  return Number.isFinite(number) ? number : 0;

}


function escapeHTML(value) {

  return String(value ?? "").replace(
    /[&<>"']/g,
    character => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    })[character]
  );

}


/* =====================================================
   4. LOAD BUSINESS INFORMATION
===================================================== */

async function loadBusinessInformation() {

  if (!currentUser) {

    throw new Error("User is not authenticated.");

  }

  businessId = currentUser.uid;

  const businessRef = doc(
    db,
    "businesses",
    businessId
  );

  const businessSnapshot = await getDoc(businessRef);

  if (!businessSnapshot.exists()) {

    throw new Error(
      "Business profile not found. Please complete business setup first."
    );

  }

  businessData = businessSnapshot.data();

  const businessName =
    businessData.businessName ||
    businessData.name ||
    "My Business";

  const businessCategory =
    businessData.businessCategory ||
    businessData.category ||
    "General Business";

  if (businessNameElement) {

    businessNameElement.textContent = businessName;

  }

  if (businessCategoryElement) {

    businessCategoryElement.textContent = businessCategory;

  }

}


/* =====================================================
   5. AUTHENTICATION CHECK
===================================================== */

onAuthStateChanged(auth, async user => {

  if (!user) {

    window.location.href = "login.html";

    return;

  }

  currentUser = user;

  try {

    await loadBusinessInformation();

    console.log(
      "Inventory authentication successful:",
      currentUser.uid
    );

    // Product loading and page initialization
    // will be connected in the following parts.

  } catch (error) {

    console.error(
      "Inventory initialization error:",
      error
    );

    showMessage(
      inventoryMessage,
      error.message || "Unable to load business information.",
      "error"
    );

  }

});


/* =====================================================
   END OF PART 1
   PART 2 WILL CONTINUE BELOW THIS LINE
===================================================== */
/* =====================================================
   ALI-HIKIMAH COMPLEX BUSINESS MANAGEMENT PLATFORM
   INVENTORY MODULE
   PART 2 OF 5
   Product Loading, Validation and Saving
===================================================== */


/* =====================================================
   6. PRODUCT COLLECTION
===================================================== */

function getProductsCollection() {

  if (!businessId) {

    throw new Error("Business ID is not available.");

  }

  return collection(
    db,
    "businesses",
    businessId,
    "products"
  );

}


/* =====================================================
   7. LOAD PRODUCTS FROM FIRESTORE
===================================================== */

async function loadProducts() {

  try {

    if (!businessId) {

      throw new Error("Business information is not ready.");

    }

    const productsQuery = query(
      getProductsCollection(),
      orderBy("createdAt", "desc")
    );

    const snapshot = await getDocs(productsQuery);

    products = snapshot.docs.map(productDocument => ({

      id: productDocument.id,

      ...productDocument.data()

    }));

    renderProducts();

    updateInventorySummary();

    console.log(
      "Products loaded:",
      products.length
    );

  } catch (error) {

    console.error("Product loading error:", error);

    showMessage(
      inventoryMessage,
      "Unable to load products: " + error.message,
      "error"
    );

  }

}


/* =====================================================
   8. VALIDATE PRODUCT INFORMATION
===================================================== */

function validateProduct(data) {

  if (!data.name.trim()) {

    return "Enter the product name.";

  }

  if (!data.productCode.trim()) {

    return "Enter the product code.";

  }

  if (!data.category.trim()) {

    return "Enter the product category.";

  }

  if (!Number.isInteger(data.quantity) || data.quantity < 0) {

    return "Quantity must be a whole number of zero or more.";

  }

  if (data.costPrice < 0 || !Number.isFinite(data.costPrice)) {

    return "Enter a valid cost price.";

  }

  if (data.sellingPrice < 0 || !Number.isFinite(data.sellingPrice)) {

    return "Enter a valid selling price.";

  }

  if (!Number.isInteger(data.lowStockLevel) || data.lowStockLevel < 0) {

    return "Low stock level must be a whole number of zero or more.";

  }

  if (!data.unit.trim()) {

    return "Enter the product unit.";

  }

  if (data.name.length > 100) {

    return "Product name cannot exceed 100 characters.";

  }

  if (data.productCode.length > 50) {

    return "Product code cannot exceed 50 characters.";

  }

  if (data.category.length > 60) {

    return "Category cannot exceed 60 characters.";

  }

  if (data.unit.length > 20) {

    return "Unit cannot exceed 20 characters.";

  }

  return null;

}


/* =====================================================
   9. COLLECT PRODUCT FORM DATA
===================================================== */

function getProductFormData() {

  return {

    name: productNameInput.value.trim(),

    productCode: productCodeInput.value.trim(),

    barcode: barcodeInput.value.trim(),

    category: categoryInput.value.trim(),

    quantity: Number(quantityInput.value),

    costPrice: Number(costPriceInput.value),

    sellingPrice: Number(sellingPriceInput.value),

    lowStockLevel: Number(lowStockLevelInput.value),

    unit: unitInput.value.trim()

  };

}


/* =====================================================
   10. CHECK FOR DUPLICATE PRODUCT CODE
===================================================== */

function productCodeExists(productCode, excludedId = null) {

  const normalizedCode = productCode.trim().toLowerCase();

  return products.some(product => {

    if (excludedId && product.id === excludedId) {

      return false;

    }

    return String(product.productCode || "")
      .trim()
      .toLowerCase() === normalizedCode;

  });

}


/* =====================================================
   11. CHECK FOR DUPLICATE BARCODE
===================================================== */

function barcodeExists(barcode, excludedId = null) {

  if (!barcode) return false;

  const normalizedBarcode = barcode.trim();

  return products.some(product => {

    if (excludedId && product.id === excludedId) {

      return false;

    }

    return String(product.barcode || "").trim() === normalizedBarcode;

  });

}


/* =====================================================
   12. SAVE NEW PRODUCT
===================================================== */

async function saveProduct(event) {

  event.preventDefault();

  clearMessage(inventoryMessage);

  if (!currentUser || !businessId) {

    showMessage(
      inventoryMessage,
      "Please wait for your business information to load.",
      "error"
    );

    return;

  }

  const formData = getProductFormData();

  const validationError = validateProduct(formData);

  if (validationError) {

    showMessage(
      inventoryMessage,
      validationError,
      "error"
    );

    return;

  }

  if (productCodeExists(formData.productCode)) {

    showMessage(
      inventoryMessage,
      "This product code already exists.",
      "error"
    );

    return;

  }

  if (barcodeExists(formData.barcode)) {

    showMessage(
      inventoryMessage,
      "This barcode is already assigned to another product.",
      "error"
    );

    return;

  }

  try {

    saveProductButton.disabled = true;

    saveProductButton.textContent = "Saving...";

    const productData = {

      name: formData.name,

      productCode: formData.productCode,

      barcode: formData.barcode,

      category: formData.category,

      quantity: formData.quantity,

      costPrice: formData.costPrice,

      sellingPrice: formData.sellingPrice,

      lowStockLevel: formData.lowStockLevel,

      unit: formData.unit,

      businessId: businessId,

      createdBy: currentUser.uid,

      createdAt: serverTimestamp(),

      updatedAt: serverTimestamp()

    };

    await addDoc(
      getProductsCollection(),
      productData
    );

    showMessage(
      inventoryMessage,
      "Product saved successfully.",
      "success"
    );

    productForm.reset();

    if (categoryFields) {

      categoryFields.hidden = true;

    }

    await loadProducts();

  } catch (error) {

    console.error("Product saving error:", error);

    showMessage(
      inventoryMessage,
      "Unable to save product: " + error.message,
      "error"
    );

  } finally {

    saveProductButton.disabled = false;

    saveProductButton.textContent = "Save Product";

  }

}


/* =====================================================
   13. CONNECT PRODUCT FORM
===================================================== */

if (productForm) {

  productForm.addEventListener(
    "submit",
    saveProduct
  );

}


/* =====================================================
   END OF PART 2
   PART 3 WILL CONTINUE BELOW THIS LINE
===================================================== */
/* =====================================================
   ALI-HIKIMAH COMPLEX BUSINESS MANAGEMENT PLATFORM
   INVENTORY MODULE
   PART 3 OF 5
   Product Display, Search and Inventory Summary
===================================================== */


/* =====================================================
   14. DETERMINE PRODUCT STOCK STATUS
===================================================== */

function getStockStatus(product) {

  const quantity = Number(product.quantity) || 0;

  const lowStockLevel = Number(product.lowStockLevel) || 0;

  if (quantity <= 0) {

    return {
      label: "Out of Stock",
      className: "out-of-stock"
    };

  }

  if (quantity <= lowStockLevel) {

    return {
      label: "Low Stock",
      className: "low-stock"
    };

  }

  return {
    label: "In Stock",
    className: "in-stock"
  };

}


/* =====================================================
   15. DISPLAY PRODUCTS IN INVENTORY TABLE
===================================================== */

function renderProducts(list = products) {

  if (!inventoryTableBody) return;

  if (!list.length) {

    inventoryTableBody.innerHTML = `
      <tr>
        <td colspan="9" class="empty-state">
          No products found in your inventory.
        </td>
      </tr>
    `;

    return;

  }

  inventoryTableBody.innerHTML = list.map(product => {

    const quantity = Number(product.quantity) || 0;

    const costPrice = Number(product.costPrice) || 0;

    const sellingPrice = Number(product.sellingPrice) || 0;

    const stockValue = quantity * costPrice;

    const status = getStockStatus(product);

    return `
      <tr>

        <td>${escapeHTML(product.name)}</td>

        <td>${escapeHTML(product.productCode || "-")}</td>

        <td>${escapeHTML(product.barcode || "-")}</td>

        <td>
          ${quantity.toLocaleString("en-NG")}
          ${escapeHTML(product.unit || "")}
        </td>

        <td>${formatMoney(costPrice)}</td>

        <td>${formatMoney(sellingPrice)}</td>

        <td>${formatMoney(stockValue)}</td>

        <td>
          <span class="stock-status ${status.className}">
            ${status.label}
          </span>
        </td>

        <td>
          <div class="action-buttons">

            <button
              type="button"
              class="edit-product-button"
              data-id="${escapeHTML(product.id)}"
            >
              Edit
            </button>

            <button
              type="button"
              class="delete-product-button danger"
              data-id="${escapeHTML(product.id)}"
            >
              Delete
            </button>

          </div>
        </td>

      </tr>
    `;

  }).join("");

}


/* =====================================================
   16. UPDATE INVENTORY SUMMARY
===================================================== */

function updateInventorySummary() {

  const totalProducts = products.length;

  const totalUnits = products.reduce(
    (total, product) => {

      return total + (Number(product.quantity) || 0);

    },
    0
  );

  const lowStockCount = products.filter(product => {

    const quantity = Number(product.quantity) || 0;

    const lowStockLevel = Number(product.lowStockLevel) || 0;

    return quantity <= lowStockLevel;

  }).length;

  const totalStockValue = products.reduce(
    (total, product) => {

      const quantity = Number(product.quantity) || 0;

      const costPrice = Number(product.costPrice) || 0;

      return total + (quantity * costPrice);

    },
    0
  );


  if (totalProductsElement) {

    totalProductsElement.textContent =
      totalProducts.toLocaleString("en-NG");

  }

  if (totalUnitsElement) {

    totalUnitsElement.textContent =
      totalUnits.toLocaleString("en-NG");

  }

  if (lowStockCountElement) {

    lowStockCountElement.textContent =
      lowStockCount.toLocaleString("en-NG");

  }

  if (totalStockValueElement) {

    totalStockValueElement.textContent =
      formatMoney(totalStockValue);

  }

}


/* =====================================================
   17. SEARCH PRODUCTS
===================================================== */

function searchProducts() {

  if (!productSearchInput) return;

  const searchTerm =
    productSearchInput.value.trim().toLowerCase();

  if (!searchTerm) {

    renderProducts();

    return;

  }

  const filteredProducts = products.filter(product => {

    const name =
      String(product.name || "").toLowerCase();

    const code =
      String(product.productCode || "").toLowerCase();

    const barcode =
      String(product.barcode || "").toLowerCase();

    const category =
      String(product.category || "").toLowerCase();

    return (
      name.includes(searchTerm) ||
      code.includes(searchTerm) ||
      barcode.includes(searchTerm) ||
      category.includes(searchTerm)
    );

  });

  renderProducts(filteredProducts);

}


/* =====================================================
   18. CONNECT SEARCH INPUT
===================================================== */

if (productSearchInput) {

  productSearchInput.addEventListener(
    "input",
    searchProducts
  );

}


/* =====================================================
   19. REFRESH INVENTORY DISPLAY
===================================================== */

async function refreshInventory() {

  await loadProducts();

  searchProducts();

}


/* =====================================================
   END OF PART 3
   PART 4 WILL CONTINUE BELOW THIS LINE
===================================================== */
/* =====================================================
   ALI-HIKIMAH COMPLEX BUSINESS MANAGEMENT PLATFORM
   INVENTORY MODULE
   PART 4 OF 5
   Edit, Update and Delete Products
===================================================== */


/* =====================================================
   20. OPEN PRODUCT EDIT FORM
===================================================== */

function openEditProduct(productId) {

  const product = products.find(
    item => item.id === productId
  );

  if (!product) {

    showMessage(
      inventoryMessage,
      "Product could not be found.",
      "error"
    );

    return;

  }

  editingProductId = productId;

  editProductIdInput.value = productId;

  editProductNameInput.value = product.name || "";

  editProductCodeInput.value = product.productCode || "";

  editBarcodeInput.value = product.barcode || "";

  editCategoryInput.value = product.category || "";

  editQuantityInput.value = product.quantity ?? 0;

  editCostPriceInput.value = product.costPrice ?? 0;

  editSellingPriceInput.value = product.sellingPrice ?? 0;

  editLowStockLevelInput.value =
    product.lowStockLevel ?? 0;

  editUnitInput.value = product.unit || "";

  clearMessage(editProductMessage);

  if (editProductPanel) {

    editProductPanel.hidden = false;

    editProductPanel.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });

  }

}


/* =====================================================
   21. UPDATE EXISTING PRODUCT
===================================================== */

async function updateProduct(event) {

  event.preventDefault();

  clearMessage(editProductMessage);

  if (!editingProductId || !businessId || !currentUser) {

    showMessage(
      editProductMessage,
      "No product selected for editing.",
      "error"
    );

    return;

  }

  const formData = {

    name: editProductNameInput.value.trim(),

    productCode: editProductCodeInput.value.trim(),

    barcode: editBarcodeInput.value.trim(),

    category: editCategoryInput.value.trim(),

    quantity: Number(editQuantityInput.value),

    costPrice: Number(editCostPriceInput.value),

    sellingPrice: Number(editSellingPriceInput.value),

    lowStockLevel: Number(editLowStockLevelInput.value),

    unit: editUnitInput.value.trim()

  };

  const validationError = validateProduct(formData);

  if (validationError) {

    showMessage(
      editProductMessage,
      validationError,
      "error"
    );

    return;

  }

  if (
    productCodeExists(
      formData.productCode,
      editingProductId
    )
  ) {

    showMessage(
      editProductMessage,
      "This product code belongs to another product.",
      "error"
    );

    return;

  }

  if (
    barcodeExists(
      formData.barcode,
      editingProductId
    )
  ) {

    showMessage(
      editProductMessage,
      "This barcode belongs to another product.",
      "error"
    );

    return;

  }

  try {

    updateProductButton.disabled = true;

    updateProductButton.textContent = "Updating...";

    const productRef = doc(
      db,
      "businesses",
      businessId,
      "products",
      editingProductId
    );

    await updateDoc(productRef, {

      name: formData.name,

      productCode: formData.productCode,

      barcode: formData.barcode,

      category: formData.category,

      quantity: formData.quantity,

      costPrice: formData.costPrice,

      sellingPrice: formData.sellingPrice,

      lowStockLevel: formData.lowStockLevel,

      unit: formData.unit,

      updatedAt: serverTimestamp()

    });

    showMessage(
      editProductMessage,
      "Product updated successfully.",
      "success"
    );

    editingProductId = null;

    editProductForm.reset();

    if (editProductPanel) {

      editProductPanel.hidden = true;

    }

    await loadProducts();

  } catch (error) {

    console.error("Product update error:", error);

    showMessage(
      editProductMessage,
      "Unable to update product: " + error.message,
      "error"
    );

  } finally {

    updateProductButton.disabled = false;

    updateProductButton.textContent = "Update Product";

  }

}


/* =====================================================
   22. CANCEL PRODUCT EDITING
===================================================== */

function cancelProductEdit() {

  editingProductId = null;

  if (editProductForm) {

    editProductForm.reset();

  }

  clearMessage(editProductMessage);

  if (editProductPanel) {

    editProductPanel.hidden = true;

  }

}


/* =====================================================
   23. DELETE PRODUCT
===================================================== */

async function deleteProduct(productId) {

  const product = products.find(
    item => item.id === productId
  );

  if (!product) {

    showMessage(
      inventoryMessage,
      "Product could not be found.",
      "error"
    );

    return;

  }

  const confirmed = window.confirm(
    `Are you sure you want to delete "${product.name}"?`
  );

  if (!confirmed) return;

  try {

    const productRef = doc(
      db,
      "businesses",
      businessId,
      "products",
      productId
    );

    await deleteDoc(productRef);

    if (editingProductId === productId) {

      cancelProductEdit();

    }

    showMessage(
      inventoryMessage,
      "Product deleted successfully.",
      "success"
    );

    await loadProducts();

  } catch (error) {

    console.error("Product deletion error:", error);

    showMessage(
      inventoryMessage,
      "Unable to delete product: " + error.message,
      "error"
    );

  }

}


/* =====================================================
   24. CONNECT INVENTORY TABLE ACTION BUTTONS
===================================================== */

if (inventoryTableBody) {

  inventoryTableBody.addEventListener(
    "click",
    event => {

      const editButton = event.target.closest(
        ".edit-product-button"
      );

      const deleteButton = event.target.closest(
        ".delete-product-button"
      );

      if (editButton) {

        const productId = editButton.dataset.id;

        openEditProduct(productId);

      }

      if (deleteButton) {

        const productId = deleteButton.dataset.id;

        deleteProduct(productId);

      }

    }
  );

}


/* =====================================================
   25. CONNECT EDIT FORM BUTTONS
===================================================== */

if (editProductForm) {

  editProductForm.addEventListener(
    "submit",
    updateProduct
  );

}

if (cancelEditButton) {

  cancelEditButton.addEventListener(
    "click",
    cancelProductEdit
  );

}


/* =====================================================
   END OF PART 4
   PART 5 WILL CONTINUE BELOW THIS LINE
===================================================== */
/* =====================================================
   ALI-HIKIMAH COMPLEX BUSINESS MANAGEMENT PLATFORM
   INVENTORY MODULE
   PART 5 OF 5
   Barcode Scanner and Final Initialization
===================================================== */


/* =====================================================
   26. DISPLAY BARCODE SCANNER MESSAGE
===================================================== */

function showScannerMessage(message, type = "info") {

  if (!barcodeScannerMessage) return;

  barcodeScannerMessage.textContent = message;

  barcodeScannerMessage.className = "message " + type;

}


/* =====================================================
   27. USE SCANNED BARCODE
===================================================== */

function useScannedBarcode(barcode) {

  if (!barcode) return;

  if (barcodeInput) {

    barcodeInput.value = barcode;

    barcodeInput.focus();

  }

  showMessage(
    inventoryMessage,
    "Barcode added successfully: " + barcode,
    "success"
  );

  stopBarcodeScanner();

}


/* =====================================================
   28. START BARCODE SCANNER
===================================================== */

async function startBarcodeScanner() {

  if (!barcodeReader) {

    showScannerMessage(
      "Barcode scanner element was not found.",
      "error"
    );

    return;

  }

  if (typeof Html5Qrcode === "undefined") {

    showScannerMessage(
      "Barcode scanner library is not available.",
      "error"
    );

    return;

  }

  try {

    if (barcodeScannerPanel) {

      barcodeScannerPanel.hidden = false;

    }

    html5QrCode = new Html5Qrcode("barcodeReader");

    showScannerMessage(
      "Starting camera. Please allow camera permission."
    );

    await html5QrCode.start(

      { facingMode: "environment" },

      {
        fps: 10,
        qrbox: {
          width: 250,
          height: 150
        }
      },

      decodedText => {

        if (decodedText) {

          useScannedBarcode(decodedText);

        }

      },

      () => {}

    );

    scannerRunning = true;

    showScannerMessage(
      "Scanner is ready. Point your camera at a barcode.",
      "success"
    );

  } catch (error) {

    console.error("Scanner error:", error);

    showScannerMessage(
      "Unable to start camera. Check camera permission or enter the barcode manually.",
      "error"
    );

  }

}


/* =====================================================
   29. STOP BARCODE SCANNER
===================================================== */

async function stopBarcodeScanner() {

  if (html5QrCode && scannerRunning) {

    try {

      await html5QrCode.stop();

      await html5QrCode.clear();

    } catch (error) {

      console.error(
        "Unable to stop scanner:",
        error
      );

    }

  }

  html5QrCode = null;

  scannerRunning = false;

  if (barcodeScannerPanel) {

    barcodeScannerPanel.hidden = true;

  }

}


/* =====================================================
   30. CONNECT BARCODE SCANNER BUTTONS
===================================================== */

if (openBarcodeScannerButton) {

  openBarcodeScannerButton.addEventListener(
    "click",
    startBarcodeScanner
  );

}

if (stopBarcodeScannerButton) {

  stopBarcodeScannerButton.addEventListener(
    "click",
    stopBarcodeScanner
  );

}


/* =====================================================
   31. MANUAL BARCODE ENTRY
===================================================== */

if (useManualBarcodeButton) {

  useManualBarcodeButton.addEventListener(
    "click",
    () => {

      const barcode = manualBarcodeInput
        ? manualBarcodeInput.value.trim()
        : "";

      if (!barcode) {

        showScannerMessage(
          "Enter a barcode first.",
          "error"
        );

        return;

      }

      useScannedBarcode(barcode);

      if (manualBarcodeInput) {

        manualBarcodeInput.value = "";

      }

    }
  );

}


/* =====================================================
   32. STOP SCANNER WHEN LEAVING PAGE
===================================================== */

window.addEventListener(
  "beforeunload",
  () => {

    if (html5QrCode && scannerRunning) {

      html5QrCode.stop().catch(error => {

        console.error(
          "Scanner cleanup error:",
          error
        );

      });

    }

  }
);


/* =====================================================
   33. FINAL INVENTORY INITIALIZATION
===================================================== */

async function initializeInventory() {

  try {

    await loadBusinessInformation();

    await loadProducts();

    console.log(
      "Inventory module initialized successfully."
    );

  } catch (error) {

    console.error(
      "Inventory initialization failed:",
      error
    );

    showMessage(
      inventoryMessage,
      error.message || "Inventory could not be initialized.",
      "error"
    );

  }

}


/* =====================================================
   END OF PART 5
   END OF INVENTORY.JS
===================================================== */