
"use strict";

import {
  auth,
  db,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  signOut,
  doc,
  setDoc,
  getDoc,
  serverTimestamp
} from "./firebase.js";

const BUSINESS_CATEGORIES = [
  "Pharmacy & Healthcare Retail",
  "Phone & Accessories",
  "Restaurant & Canteen",
  "Boutique & Fashion",
  "Supermarket & Grocery",
  "Cosmetics & Beauty",
  "Building Materials & Hardware",
  "Electronics & Appliances",
  "Wholesale & Distribution",
  "General Retail & Other"
];

function getFriendlyAuthError(error) {
  const code = error?.code || "";

  const messages = {
    "auth/email-already-in-use":
      "This email already has an account. Sign in to continue.",
    "auth/invalid-email":
      "Please enter a valid email address.",
    "auth/weak-password":
      "Use a password with at least 6 characters.",
    "auth/invalid-credential":
      "The email or password is incorrect.",
    "auth/user-not-found":
      "No account was found for these login details.",
    "auth/wrong-password":
      "The email or password is incorrect.",
    "auth/too-many-requests":
      "Too many attempts. Wait a while and try again.",
    "auth/network-request-failed":
      "Network error. Check your internet connection.",
    "permission-denied":
      "Firestore denied access. Check your database security rules.",
    "firestore/permission-denied":
      "Firestore denied access. Check your database security rules."
  };

  return messages[code] ||
    error?.message ||
    "An unexpected error occurred.";
}

function validateBusinessProfile(profile) {
  if (!profile || typeof profile !== "object") {
    throw new Error("Business information is missing.");
  }

  const requiredFields = [
    "ownerName",
    "ownerEmail",
    "ownerPhone",
    "businessName",
    "category",
    "location"
  ];

  for (const field of requiredFields) {
    if (
      typeof profile[field] !== "string" ||
      !profile[field].trim()
    ) {
      throw new Error("Please provide valid business information.");
    }
  }

  if (!BUSINESS_CATEGORIES.includes(profile.category)) {
    throw new Error("Please select a valid business category.");
  }
}

/**
 * Create the owner's business profile.
 * Call only after Firebase Authentication succeeds.
 */
async function saveBusinessProfile(user, profile) {
  if (!user?.uid) {
    throw new Error("You must be signed in to save a business profile.");
  }

  validateBusinessProfile(profile);

  const businessRef = doc(db, "businesses", user.uid);
  const userRef = doc(db, "users", user.uid);

  const existingBusiness = await getDoc(businessRef);

  if (existingBusiness.exists()) {
    const current = existingBusiness.data();

    if (current.ownerUid !== user.uid) {
      throw new Error("This business profile belongs to another account.");
    }
  } else {
    await setDoc(businessRef, {
      businessId: user.uid,
      ownerUid: user.uid,
      ownerName: profile.ownerName.trim(),
      ownerEmail: user.email || profile.ownerEmail.trim().toLowerCase(),
      ownerPhone: profile.ownerPhone.trim(),
      businessName: profile.businessName.trim(),
      category: profile.category,
      location: profile.location.trim(),
      status: "pending_setup",
      createdAt: serverTimestamp()
    });
  }

  const existingUser = await getDoc(userRef);

  if (!existingUser.exists()) {
    await setDoc(userRef, {
      uid: user.uid,
      fullName: profile.ownerName.trim(),
      email: user.email || profile.ownerEmail.trim().toLowerCase(),
      phone: profile.ownerPhone.trim(),
      role: "owner",
      businessId: user.uid,
      createdAt: serverTimestamp()
    });
  }

  return {
    businessId: user.uid,
    businessRef
  };
}

/**
 * Recover profile setup for an existing authenticated account.
 * The user must sign in first; this does not create another account.
 */
async function completeExistingRegistration(profile) {
  const user = auth.currentUser;

  if (!user) {
    throw new Error(
      "Please sign in with the account that was already created, then retry profile setup."
    );
  }

  await saveBusinessProfile(user, profile);

  return {
    success: true,
    message: "Your business profile has been saved.",
    businessId: user.uid
  };
}

export {
  BUSINESS_CATEGORIES,
  getFriendlyAuthError,
  validateBusinessProfile,
  saveBusinessProfile,
  completeExistingRegistration,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  signOut,
  getDoc,
  doc,
  setDoc,
  serverTimestamp,
  auth,
  db
};
