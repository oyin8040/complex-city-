
"use strict";

const express = require("express");
const router = express.Router();
const admin = require("firebase-admin");
const crypto = require("crypto");

const { auth, db } = require("../config/firebase");

const FieldValue = admin.firestore.FieldValue;

const STAFF_LOGIN_URL =
  "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword";


// ======================================
// 1. VERIFY BUSINESS OWNER
// ======================================

async function verifyOwner(req, res, next) {
  try {
    const header = req.headers.authorization || "";

    if (!header.startsWith("Bearer ")) {
      return res.status(401).json({
        success: false,
        message: "Please log in as the business owner."
      });
    }

    const decoded = await auth.verifyIdToken(header.slice(7));

    const businessId = decoded.uid;

    const [businessSnap, userSnap] = await Promise.all([
      db.collection("businesses").doc(businessId).get(),
      db.collection("users").doc(decoded.uid).get()
    ]);

    if (!businessSnap.exists || !userSnap.exists) {
      return res.status(403).json({
        success: false,
        message: "Owner business account was not found."
      });
    }

    const business = businessSnap.data();
    const user = userSnap.data();

    if (
      business.ownerUid !== decoded.uid ||
      business.businessId !== businessId ||
      user.role !== "owner" ||
      user.businessId !== businessId
    ) {
      return res.status(403).json({
        success: false,
        message: "Only the verified business owner can manage staff."
      });
    }

    if (["suspended", "disabled"].includes(business.status)) {
      return res.status(403).json({
        success: false,
        message: "This business account is not active."
      });
    }

    req.owner = {
      uid: decoded.uid,
      businessId,
      business
    };

    return next();

  } catch (error) {
    console.error("Owner verification failed:", error.message);

    return res.status(401).json({
      success: false,
      message: "Authentication failed. Please log in again."
    });
  }
}


// ======================================
// 2. STAFF ROUTE HEALTH CHECK
// ======================================

router.get("/health", (req, res) => {
  return res.status(200).json({
    success: true,
    message: "Staff routes are working."
  });
});


// ======================================
// 3. STAFF LOGIN
// Staff ID + password
// ======================================

router.post("/login", async (req, res) => {
  try {
    const staffId =
      typeof req.body.staffId === "string"
        ? req.body.staffId.trim().toUpperCase()
        : "";

    const password = req.body.password;
    const apiKey = process.env.FIREBASE_WEB_API_KEY;

    if (!/^STAFF[0-9]{6}$/.test(staffId)) {
      return res.status(400).json({
        success: false,
        message: "Enter a valid Staff ID."
      });
    }

    if (
      typeof password !== "string" ||
      password.length === 0
    ) {
      return res.status(400).json({
        success: false,
        message: "Enter your password."
      });
    }

    if (!apiKey) {
      console.error("FIREBASE_WEB_API_KEY is missing.");

      return res.status(503).json({
        success: false,
        message: "Staff login is not configured yet."
      });
    }

    const directoryRef = db
      .collection("staffDirectory")
      .doc(staffId);

    const directorySnap = await directoryRef.get();

    if (!directorySnap.exists) {
      return res.status(401).json({
        success: false,
        message: "Invalid Staff ID or password."
      });
    }

    const directory = directorySnap.data();

    if (
      directory.status !== "active" ||
      !directory.uid ||
      !directory.businessId ||
      !directory.ownerUid ||
      !directory.authEmail
    ) {
      return res.status(403).json({
        success: false,
        message: "This staff account is not active."
      });
    }

    const staffRef = db
      .collection("businesses")
      .doc(directory.businessId)
      .collection("staff")
      .doc(staffId);

    const staffSnap = await staffRef.get();

    if (!staffSnap.exists) {
      return res.status(401).json({
        success: false,
        message: "Invalid Staff ID or password."
      });
    }

    const staff = staffSnap.data();

    if (
      staff.uid !== directory.uid ||
      staff.businessId !== directory.businessId ||
      staff.ownerUid !== directory.ownerUid ||
      staff.staffId !== staffId ||
      staff.status !== "active"
    ) {
      return res.status(403).json({
        success: false,
        message: "This staff account is not active."
      });
    }

    const businessSnap = await db
      .collection("businesses")
      .doc(directory.businessId)
      .get();

    if (!businessSnap.exists) {
      return res.status(403).json({
        success: false,
        message: "The assigned business could not be found."
      });
    }

    const business = businessSnap.data();

    if (
      business.ownerUid !== directory.ownerUid ||
      business.businessId !== directory.businessId ||
      ["suspended", "disabled"].includes(business.status)
    ) {
      return res.status(403).json({
        success: false,
        message: "This business account is not active."
      });
    }

    // Verify password with Firebase Authentication.

    const authResponse = await fetch(
      `${STAFF_LOGIN_URL}?key=${encodeURIComponent(apiKey)}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email: directory.authEmail,
          password,
          returnSecureToken: true
        })
      }
    );

    const authResult = await authResponse.json().catch(() => ({}));

    if (!authResponse.ok || !authResult.idToken) {
      return res.status(401).json({
        success: false,
        message: "Invalid Staff ID or password."
      });
    }

    const decoded = await auth.verifyIdToken(
      authResult.idToken
    );

    if (
      decoded.uid !== directory.uid ||
      decoded.email !== directory.authEmail ||
      decoded.role !== "staff" ||
      decoded.staffId !== staffId ||
      decoded.businessId !== directory.businessId
    ) {
      return res.status(403).json({
        success: false,
        message: "Staff account verification failed."
      });
    }

    const customToken = await auth.createCustomToken(
      decoded.uid,
      {
        role: "staff",
        staffId,
        businessId: directory.businessId
      }
    );

    return res.status(200).json({
      success: true,
      message: "Staff login successful.",
      customToken,
      staff: {
        uid: staff.uid,
        staffId,
        name: staff.name,
        role: staff.role,
        businessId: staff.businessId,
        businessName: business.businessName || ""
      }
    });

  } catch (error) {
    console.error("Staff login failed:", error.message);

    return res.status(500).json({
      success: false,
      message: "Unable to sign in. Please try again."
    });
  }
});


// ======================================
// 4. LIST STAFF
// ======================================

router.get("/", verifyOwner, async (req, res) => {
  try {
    const snapshot = await db
      .collection("businesses")
      .doc(req.owner.businessId)
      .collection("staff")
      .get();

    const staff = snapshot.docs.map((document) => {
      const data = document.data();

      return {
        id: document.id,
        staffId: data.staffId || document.id,
        name: data.name || "",
        role: data.role || "cashier",
        status: data.status || "active",
        createdAt: data.createdAt || null
      };
    });

    return res.status(200).json({
      success: true,
      message: "Staff list retrieved successfully.",
      staff
    });

  } catch (error) {
    console.error("Staff listing failed:", error.message);

    return res.status(500).json({
      success: false,
      message: "Unable to retrieve staff at this time."
    });
  }
});


// ======================================
// 5. CREATE STAFF ACCOUNT
// ======================================

router.post("/", verifyOwner, async (req, res) => {
  let reservedRef = null;
  let createdAuthUser = null;
  let staffId = null;
  let authEmail = null;
  let committed = false;

  try {
    const name =
      typeof req.body.name === "string"
        ? req.body.name.trim()
        : "";

    const role = req.body.role || "cashier";
    const password = req.body.password;

    if (name.length < 2 || name.length > 100) {
      return res.status(400).json({
        success: false,
        message: "Enter a staff name between 2 and 100 characters."
      });
    }

    if (role !== "cashier") {
      return res.status(400).json({
        success: false,
        message: "Only the cashier role is currently supported."
      });
    }

    if (
      typeof password !== "string" ||
      password.length < 8 ||
      password.length > 64
    ) {
      return res.status(400).json({
        success: false,
        message: "The staff password must be 8 to 64 characters."
      });
    }

    if (req.body.businessId !== req.owner.businessId) {
      return res.status(403).json({
        success: false,
        message: "You cannot create staff for another business."
      });
    }

    const businessId = req.owner.businessId;

    // Reserve a globally unique Staff ID.

    for (let attempt = 0; attempt < 10; attempt++) {
      const candidate =
        `STAFF${crypto.randomInt(100000, 1000000)}`;

      const candidateEmail =
        `${candidate.toLowerCase()}@staff.ali-hikimah.com`;

      const candidateRef = db
        .collection("staffDirectory")
        .doc(candidate);

      const reserved = await db.runTransaction(
        async (transaction) => {
          const existing = await transaction.get(candidateRef);

          if (existing.exists) {
            return false;
          }

          transaction.create(candidateRef, {
            staffId: candidate,
            businessId,
            ownerUid: req.owner.uid,
            authEmail: candidateEmail,
            status: "provisioning",
            createdAt: FieldValue.serverTimestamp()
          });

          return true;
        }
      );

      if (reserved) {
        staffId = candidate;
        authEmail = candidateEmail;
        reservedRef = candidateRef;
        break;
      }
    }

    if (!reservedRef) {
      return res.status(503).json({
        success: false,
        message: "Unable to generate a unique Staff ID. Try again."
      });
    }

    // Create Firebase Authentication account.

    createdAuthUser = await auth.createUser({
      email: authEmail,
      password,
      displayName: name,
      disabled: false
    });

    await auth.setCustomUserClaims(createdAuthUser.uid, {
      role: "staff",
      businessId,
      staffId
    });

    const staffRef = db
      .collection("businesses")
      .doc(businessId)
      .collection("staff")
      .doc(staffId);

    const userRef = db
      .collection("users")
      .doc(createdAuthUser.uid);

    const batch = db.batch();
    const timestamp = FieldValue.serverTimestamp();

    batch.set(staffRef, {
      staffId,
      uid: createdAuthUser.uid,
      ownerUid: req.owner.uid,
      businessId,
      name,
      role,
      status: "active",
      authEmail,
      createdAt: timestamp,
      updatedAt: timestamp
    });

    batch.set(userRef, {
      uid: createdAuthUser.uid,
      fullName: name,
      role: "staff",
      staffId,
      businessId,
      ownerUid: req.owner.uid,
      createdAt: timestamp
    });

    batch.update(reservedRef, {
      uid: createdAuthUser.uid,
      status: "active",
      updatedAt: timestamp
    });

    await batch.commit();
    committed = true;

    return res.status(201).json({
      success: true,
      message: "Staff account created successfully.",
      staff: {
        id: staffId,
        staffId,
        name,
        role,
        status: "active"
      }
    });

  } catch (error) {
    console.error("Staff creation failed:", error.message);

    if (!committed && createdAuthUser) {
      try {
        await auth.deleteUser(createdAuthUser.uid);
      } catch (cleanupError) {
        console.error(
          "Staff account cleanup failed:",
          cleanupError.message
        );
      }
    }

    if (!committed && reservedRef) {
      try {
        const reservation = await reservedRef.get();

        if (
          reservation.exists &&
          reservation.data().ownerUid === req.owner.uid &&
          reservation.data().staffId === staffId
        ) {
          await reservedRef.delete();
        }
      } catch (cleanupError) {
        console.error(
          "Staff ID cleanup failed:",
          cleanupError.message
        );
      }
    }

    return res.status(500).json({
      success: false,
      message: "Staff account creation failed. Please try again."
    });
  }
});


// ======================================
// 6. RESET STAFF PASSWORD
// ======================================

router.patch("/:staffId/password", verifyOwner, async (req, res) => {
  try {
    const staffId = req.params.staffId;
    const password = req.body.password;
    const businessId = req.body.businessId;

    if (businessId !== req.owner.businessId) {
      return res.status(403).json({
        success: false,
        message: "Business access denied."
      });
    }

    if (
      typeof password !== "string" ||
      password.length < 8 ||
      password.length > 64
    ) {
      return res.status(400).json({
        success: false,
        message: "Password must contain 8 to 64 characters."
      });
    }

    const staffRef = db
      .collection("businesses")
      .doc(businessId)
      .collection("staff")
      .doc(staffId);

    const directoryRef = db
      .collection("staffDirectory")
      .doc(staffId);

    const [staffSnap, directorySnap] = await Promise.all([
      staffRef.get(),
      directoryRef.get()
    ]);

    if (!staffSnap.exists || !directorySnap.exists) {
      return res.status(404).json({
        success: false,
        message: "Staff account not found."
      });
    }

    const staff = staffSnap.data();
    const directory = directorySnap.data();

    if (
      !staff.uid ||
      staff.ownerUid !== req.owner.uid ||
      staff.businessId !== businessId ||
      directory.uid !== staff.uid ||
      directory.ownerUid !== req.owner.uid ||
      directory.businessId !== businessId ||
      directory.status !== staff.status
    ) {
      return res.status(403).json({
        success: false,
        message: "You cannot manage this staff account."
      });
    }

    await auth.updateUser(staff.uid, {
      password
    });

    await staffRef.update({
      updatedAt: FieldValue.serverTimestamp()
    });

    return res.status(200).json({
      success: true,
      message: "Staff password updated successfully."
    });

  } catch (error) {
    console.error("Password reset failed:", error.message);

    return res.status(500).json({
      success: false,
      message: "Unable to reset staff password."
    });
  }
});


// ======================================
// 7. ACTIVATE OR DISABLE STAFF
// ======================================

router.patch("/:staffId/status", verifyOwner, async (req, res) => {
  try {
    const staffId = req.params.staffId;
    const status = req.body.status;
    const businessId = req.body.businessId;

    if (businessId !== req.owner.businessId) {
      return res.status(403).json({
        success: false,
        message: "Business access denied."
      });
    }

    if (!["active", "disabled"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid staff account status."
      });
    }

    const staffRef = db
      .collection("businesses")
      .doc(businessId)
      .collection("staff")
      .doc(staffId);

    const directoryRef = db
      .collection("staffDirectory")
      .doc(staffId);

    const [staffSnap, directorySnap] = await Promise.all([
      staffRef.get(),
      directoryRef.get()
    ]);

    if (!staffSnap.exists || !directorySnap.exists) {
      return res.status(404).json({
        success: false,
        message: "Staff account not found."
      });
    }

    const staff = staffSnap.data();
    const directory = directorySnap.data();

    if (
      !staff.uid ||
      staff.ownerUid !== req.owner.uid ||
      staff.businessId !== businessId ||
      directory.uid !== staff.uid ||
      directory.ownerUid !== req.owner.uid ||
      directory.businessId !== businessId
    ) {
      return res.status(403).json({
        success: false,
        message: "You cannot manage this staff account."
      });
    }

    const previousDisabled = staff.status !== "active";

    // Update Firebase Authentication first.

    await auth.updateUser(staff.uid, {
      disabled: status === "disabled"
    });

    try {
      const batch = db.batch();
      const timestamp = FieldValue.serverTimestamp();

      batch.update(staffRef, {
        status,
        updatedAt: timestamp
      });

      batch.update(directoryRef, {
        status,
        updatedAt: timestamp
      });

      await batch.commit();

    } catch (databaseError) {
      // Attempt to restore the previous authentication state.

      try {
        await auth.updateUser(staff.uid, {
          disabled: previousDisabled
        });
      } catch (rollbackError) {
        console.error(
          "Authentication rollback failed:",
          rollbackError.message
        );
      }

      throw databaseError;
    }

    return res.status(200).json({
      success: true,
      message: `Staff account ${status} successfully.`
    });

  } catch (error) {
    console.error("Staff status update failed:", error.message);

    return res.status(500).json({
      success: false,
      message: "Unable to update staff account."
    });
  }
});


module.exports = router;
