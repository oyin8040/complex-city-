"use strict";

const express = require("express");

const router = express.Router();

// Check the business API
router.get("/health", (req, res) => {
res.status(200).json({
success: true,
message: "Business routes are working."
});
});

// Get the business list
router.get("/", (req, res) => {
res.status(200).json({
success: true,
message: "Business list retrieved successfully.",
businesses: []
});
});

// Create a business (temporary placeholder)
router.post("/", (req, res) => {
res.status(501).json({
success: false,
message: "Business creation is not implemented yet."
});
});

module.exports = router;