
"use strict";

const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve public website files: HTML, CSS, and JavaScript
const publicDirectory = path.join(__dirname, "public");

app.use(express.static(publicDirectory));

// Homepage
app.get("/", (req, res) => {
  res.sendFile(path.join(publicDirectory, "index.html"));
});

// API health check
app.get("/api/health", (req, res) => {
  res.status(200).json({
    success: true,
    message: "Ali-Hikimah platform server is running.",
    status: "healthy"
  });
});


 // Load authentication routes
const authRoutes = require("./routes/authRoutes");
app.use("/api/auth", authRoutes);

// Load business routes
const businessRoutes = require("./routes/businessRoutes");
app.use("/api/businesses", businessRoutes);

// Load staff routes
const staffRoutes = require("./routes/staffRoutes");
app.use("/api/staff", staffRoutes);

// API 404 handler
app.use("/api", (req, res) => {
  res.status(404).json({
    success: false,
    message: "API endpoint not found."
  });
});

// General error handler
app.use((err, req, res, next) => {
  console.error("Server error:", err.message);

  res.status(err.status || 500).json({
    success: false,
    message: "An unexpected server error occurred."
  });
});

// Start server
app.listen(PORT, "0.0.0.0", () => {
  console.log(
    `Ali-Hikimah platform running on port ${PORT}`
  );
});
